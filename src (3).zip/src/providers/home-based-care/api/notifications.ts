import { hbcApi, getHbcProviderType } from "./client";

export function getNotifications(providerId: string) {
  const type = getHbcProviderType();
  const resource = type === "NURSE" ? "nurses" : type === "CARETAKER" ? "caretakers" : "physiotherapists";
  const headers = type === "NURSE"
    ? { "X-Nurse-Id": providerId }
    : { "X-Care-Provider-Id": providerId, "X-Care-Provider-Type": type };
  return hbcApi(`/${resource}/${encodeURIComponent(providerId)}/notifications?page=0&size=20`, { headers });
}

export function markNotificationRead(providerId: string, notificationId: string) {
  const type = getHbcProviderType();
  const resource = type === "NURSE" ? "nurses" : type === "CARETAKER" ? "caretakers" : "physiotherapists";
  const headers = type === "NURSE"
    ? { "X-Nurse-Id": providerId }
    : { "X-Care-Provider-Id": providerId, "X-Care-Provider-Type": type };
  return hbcApi(`/${resource}/${encodeURIComponent(providerId)}/notifications/${encodeURIComponent(notificationId)}/read`, {
    method: "POST",
    headers,
  });
}
