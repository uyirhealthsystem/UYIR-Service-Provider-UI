import { hbcApi, getHbcProviderType } from "./client";

export function rateUser(bookingId: string, providerId: string, stars: number, comment?: string) {
  const type = getHbcProviderType();
  const path = type === "NURSE" ? `/bookings/${bookingId}/ratings/provider-to-user` : `/bookings/${bookingId}/ratings/provider-to-user`;
  const headers = type === "NURSE"
    ? { "X-Nurse-Id": providerId }
    : { "X-Care-Provider-Id": providerId, "X-Care-Provider-Type": type };
  return hbcApi(path, { method: "POST", headers, body: JSON.stringify({ stars, comment }) });
}
