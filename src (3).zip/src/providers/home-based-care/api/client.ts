import { getAccessToken } from "../../../auth/session";
import { getUserIdFromAccessToken } from "../../../auth/token";
import { BASE_URL } from "../config/env";

let hbcUserId = "";
let hbcProviderId = "";
let hbcProviderType = "";

export function setHbcUserId(userId: string | null | undefined) {
  hbcUserId = userId || "";
}

export function setHbcProviderId(providerId: string | null | undefined) {
  hbcProviderId = providerId || "";
}

export function setHbcProviderType(providerType: string | null | undefined) {
  hbcProviderType = String(providerType || "").toUpperCase();
}

export function getHbcUserId() {
  return hbcUserId;
}

export function getHbcProviderId() {
  return hbcProviderId;
}

export function getHbcProviderType() {
  return hbcProviderType;
}

export function getHbcAuth() {
  const accessToken = getAccessToken();
  const userId = hbcUserId || (accessToken ? getUserIdFromAccessToken(accessToken) : "");
  if (!accessToken) throw new Error("Access token is missing. Please login again.");
  if (!userId) throw new Error("User ID (JWT sub) is missing from the access token.");
  return { accessToken, userId };
}

export async function hbcApi(path: string, options: RequestInit = {}) {
  const { accessToken, userId } = getHbcAuth();
  const url = `${BASE_URL}/api/v1/hbc${path.startsWith("/") ? path : `/${path}`}`;
  const headers = new Headers(options.headers || {});
  headers.set("Accept", "application/json");
  headers.set("Authorization", `Bearer ${accessToken}`);
  headers.set("X-User-Id", userId);
  if (options.body && !(options.body instanceof FormData) && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }

  console.log("HBC API:", options.method || "GET", url);
  console.log("HBC JWT sub / X-User-Id:", userId);

  const response = await fetch(url, { ...options, headers });
  const raw = await response.text();
  let data: any = null;
  try {
    data = raw ? JSON.parse(raw) : null;
  } catch {
    data = raw;
  }

  if (!response.ok) {
    const error = new Error(data?.detail || data?.message || data?.error?.message || data?.error || raw || `HBC API request failed (${response.status})`);
    (error as any).status = response.status;
    (error as any).data = data;
    throw error;
  }
  return data;
}
