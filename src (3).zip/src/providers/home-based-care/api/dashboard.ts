import { hbcApi, getHbcProviderType } from "./client";

function providerHeaders(providerId: string) {
  const type = getHbcProviderType();
  return type === "NURSE"
    ? { "X-Nurse-Id": providerId }
    : { "X-Care-Provider-Id": providerId, "X-Care-Provider-Type": type };
}

function providerPath(providerId: string, suffix: string) {
  const type = getHbcProviderType();
  const resource = type === "NURSE" ? "nurses" : type === "CARETAKER" ? "caretakers" : "physiotherapists";
  return `/${resource}/${encodeURIComponent(providerId)}/${suffix}`;
}

export function getDashboard(providerId: string) {
  return hbcApi(providerPath(providerId, "dashboard"), { headers: providerHeaders(providerId) });
}

export function getBookingHistory(providerId: string, filter = "ALL") {
  return hbcApi(providerPath(providerId, `bookings?filter=${encodeURIComponent(filter)}&page=0&size=20`), {
    headers: providerHeaders(providerId),
  });
}
