import { getAccessToken, getAuthUserId } from "../../../auth/session";
import { getUserIdFromAccessToken } from "../../../auth/token";
import { hbcApi } from "./client";

export function getNurseProfile() {
  return hbcApi("/nurses/profile");
}

export function getCaretakerProfile() {
  return hbcApi("/caretakers/profile");
}

export function getPhysiotherapistProfile() {
  return hbcApi("/physiotherapists/profile");
}

export function getCurrentHbcUserId() {
  const token = getAccessToken();

  return getAuthUserId() || (token ? getUserIdFromAccessToken(token) : "");
}
