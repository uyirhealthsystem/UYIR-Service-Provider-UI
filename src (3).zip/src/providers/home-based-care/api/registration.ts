import { hbcApi } from "./client";

export type HbcRegistrationPayload = {
  fullName: string; phone: string; email: string; address: string; qualification: string;
  yearsExperience: number; specialization: string; jobType: string; serviceablePinCodes: string[];
  latitude: number; longitude: number; supportedServices: string[]; status: string;
};

export function createNurse(payload: HbcRegistrationPayload) {
  return hbcApi("/nurses", { method: "POST", body: JSON.stringify(payload) });
}

export function createCaretaker(payload: HbcRegistrationPayload) {
  return hbcApi("/caretakers", { method: "POST", body: JSON.stringify(payload) });
}

export function createPhysiotherapist(payload: HbcRegistrationPayload) {
  return hbcApi("/physiotherapists", { method: "POST", body: JSON.stringify(payload) });
}
