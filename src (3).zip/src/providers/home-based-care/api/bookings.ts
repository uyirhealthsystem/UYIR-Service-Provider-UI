import { getHbcProviderType, hbcApi } from "./client";

function providerHeaders(providerId: string) {
  const type = getHbcProviderType();
  if (type === "NURSE") return { "X-Nurse-Id": providerId };
  return { "X-Care-Provider-Id": providerId, "X-Care-Provider-Type": type };
}

function providerPath(providerId: string, suffix: string) {
  const type = getHbcProviderType();
  const resource =
    type === "NURSE"
      ? "nurses"
      : type === "CARETAKER"
        ? "caretakers"
        : "physiotherapists";
  return `/${resource}/${providerId}/${suffix}`;
}

export function getServicePool(providerId: string, status = "OFFERED") {
  return hbcApi(
    providerPath(
      providerId,
      `service-pool?status=${encodeURIComponent(status)}&page=0&size=20&sort=distanceKm,asc`,
    ),
    {
      headers: providerHeaders(providerId),
    },
  );
}

export function getBooking(bookingId: string) {
  return hbcApi(`/bookings/${encodeURIComponent(bookingId)}`);
}

export function acceptBooking(bookingId: string, providerId: string) {
  return hbcApi(`/bookings/${encodeURIComponent(bookingId)}/accept`, {
    method: "POST",
    headers: providerHeaders(providerId),
  });
}

export function getCareDetails(bookingId: string, providerId: string) {
  return hbcApi(`/bookings/${encodeURIComponent(bookingId)}/care-details`, {
    headers: providerHeaders(providerId),
  });
}

export function getPrescriptions(bookingId: string, providerId: string) {
  return hbcApi(`/bookings/${encodeURIComponent(bookingId)}/prescriptions`, {
    headers: providerHeaders(providerId),
  });
}

export function saveClinicalDetails(
  bookingId: string,
  providerId: string,
  body: any,
) {
  return hbcApi(`/bookings/${encodeURIComponent(bookingId)}/clinical-details`, {
    method: "PUT",
    headers: providerHeaders(providerId),
    body: JSON.stringify(body),
  });
}

export function confirmBooking(bookingId: string, providerId: string) {
  return hbcApi(
    `/bookings/${encodeURIComponent(bookingId)}/provider-confirmation`,
    {
      method: "POST",
      headers: providerHeaders(providerId),
    },
  );
}

export function getVisits(bookingId: string) {
  return hbcApi(`/bookings/${encodeURIComponent(bookingId)}/visits`);
}

export function startVisit(
  visitId: string,
  providerId: string,
  servicePin: string,
) {
  return hbcApi(`/visits/${encodeURIComponent(visitId)}/start`, {
    method: "POST",
    headers: providerHeaders(providerId),
    body: JSON.stringify({ servicePin }),
  });
}

export function completeVisit(visitId: string, providerId: string) {
  return hbcApi(`/visits/${encodeURIComponent(visitId)}/complete`, {
    method: "POST",
    headers: providerHeaders(providerId),
  });
}

export function cancelAcceptedBooking(
  bookingId: string,
  providerId: string,
  reason: string,
) {
  return hbcApi(`/bookings/${encodeURIComponent(bookingId)}/provider-cancel`, {
    method: "POST",
    headers: providerHeaders(providerId),
    body: JSON.stringify({ reason }),
  });
}

export function getBookingServicePool(bookingId: string) {
  return hbcApi(
    `/bookings/${encodeURIComponent(bookingId)}/service-pool?page=0&size=20&sort=distanceKm,asc`,
  );
}
