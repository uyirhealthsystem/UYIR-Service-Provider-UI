import { createNativeStackNavigator } from "@react-navigation/native-stack";
import BookingDetails from "./features/booking/screens/BookingDetails";
import Map from "./features/booking/screens/Map";
import HomeBasedCareLayout from "./layout";
import { HbcProvider } from "./features/provider-state/store";
const Stack = createNativeStackNavigator();
export default function HomeBasedCareRoutes() {
  return (
    <HbcProvider>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="HomeCareLayout" component={HomeBasedCareLayout} />
        <Stack.Screen
          name="HomeCareBookingDetails"
          component={BookingDetails}
        />
        <Stack.Screen name="HomeCareMap" component={Map} />
      </Stack.Navigator>
    </HbcProvider>
  );
}
