import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react";

import { getAccessToken } from "../../../../auth/session";
import { useAuth } from "../../../../auth/store";
import { getUserIdFromAccessToken } from "../../../../auth/token";

import {
  getCaretakerProfile,
  getNurseProfile,
  getPhysiotherapistProfile,
} from "../../api/profile";

import {
  setHbcProviderId,
  setHbcProviderType,
  setHbcUserId,
} from "../../api/client";

type HbcStore = {
  userId: string;
  providerId: string;
  providerType: string;
  user: any;
  profile: any;
  loading: boolean;
  error: string;
  refresh: () => Promise<void>;
};

const HbcContext = createContext<HbcStore | undefined>(undefined);

const PROFILE_APIS = [
  {
    type: "NURSE",
    load: getNurseProfile,
  },
  {
    type: "CARETAKER",
    load: getCaretakerProfile,
  },
  {
    type: "PHYSIOTHERAPIST",
    load: getPhysiotherapistProfile,
  },
];

function extractProfile(response: any) {
  return (
    response?.data?.profile ??
    response?.data?.data?.profile ??
    response?.data?.data ??
    response?.data ??
    response?.profile ??
    response
  );
}

function extractProviderId(profile: any) {
  const id =
    profile?.id ??
    profile?.providerId ??
    profile?.nurseId ??
    profile?.caretakerId ??
    profile?.physiotherapistId;

  return id ? String(id) : "";
}

function getErrorStatus(error: any) {
  return error?.status ?? error?.response?.status;
}

export function HbcProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();

  const [userId, setUserId] = useState("");
  const [providerId, setProviderId] = useState("");
  const [providerType, setProviderType] = useState("");
  const [hbcUser, setHbcUser] = useState<any>(null);
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const loadIdentity = async () => {
    try {
      setLoading(true);
      setError("");

      const accessToken = getAccessToken() || user?.accessToken || "";

      const authUserId = accessToken
        ? getUserIdFromAccessToken(accessToken)
        : user?.sub || user?.id || "";

      if (!accessToken) {
        throw new Error("Access token is missing. Please log in again.");
      }

      if (!authUserId) {
        throw new Error("User ID was not found in the access token.");
      }

      // This is the Auth user ID. HBC profile APIs receive it
      // through X-User-Id in hbcApi.
      setUserId(authUserId);
      setHbcUserId(authUserId);

      const currentType = String(
        user?.providerType || user?.role || "",
      ).toUpperCase();

      const matchingProfileApi = PROFILE_APIS.find(
        (item) => item.type === currentType,
      );

      let resolvedProfile: any = null;
      let resolvedType = "";
      let resolvedProviderId = "";

      if (matchingProfileApi) {
        const response = await matchingProfileApi.load();
        resolvedProfile = extractProfile(response);
        resolvedProviderId = extractProviderId(resolvedProfile);
        resolvedType = matchingProfileApi.type;

        if (!resolvedProviderId) {
          throw new Error(
            `${resolvedType} profile response did not contain a provider ID.`,
          );
        }
      } else {
        // The Auth role may only say HBC. Try each provider profile
        // endpoint until the matching registered profile is found.
        let lastError: any = null;

        for (const item of PROFILE_APIS) {
          try {
            const response = await item.load();
            const candidate = extractProfile(response);
            const candidateId = extractProviderId(candidate);

            if (candidateId) {
              resolvedProfile = candidate;
              resolvedProviderId = candidateId;
              resolvedType = item.type;
              break;
            }
          } catch (profileError: any) {
            lastError = profileError;
            const status = getErrorStatus(profileError);

            // A missing subtype may return 404 or 400.
            // Other errors should not be treated as "not registered".
            if (status !== 404 && status !== 400) {
              throw profileError;
            }
          }
        }

        if (!resolvedProviderId) {
          throw (
            lastError ||
            new Error(
              "No registered HBC nurse, caretaker, or physiotherapist profile was found.",
            )
          );
        }
      }

      setProfile(resolvedProfile);
      setProviderId(resolvedProviderId);
      setProviderType(resolvedType);

      setHbcProviderId(resolvedProviderId);
      setHbcProviderType(resolvedType);

      setHbcUser({
        ...user,
        id: authUserId,
        sub: authUserId,
        providerType: resolvedType,
      });

      console.log("HBC Auth user ID:", authUserId);
      console.log("HBC provider type:", resolvedType);
      console.log("HBC provider profile ID:", resolvedProviderId);
      console.log("HBC profile loaded:", true);
    } catch (identityError: any) {
      console.log("HBC identity API error:", identityError);

      setError(
        identityError?.message || "Unable to load HBC provider profile.",
      );

      setProfile(null);
      setProviderId("");
      setProviderType("");
      setHbcProviderId("");
      setHbcProviderType("");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadIdentity();
  }, [user?.sub, user?.id, user?.providerType, user?.role, user?.accessToken]);

  return (
    <HbcContext.Provider
      value={{
        userId,
        providerId,
        providerType,
        user: hbcUser,
        profile,
        loading,
        error,
        refresh: loadIdentity,
      }}
    >
      {children}
    </HbcContext.Provider>
  );
}

export function useHbcStore() {
  const context = useContext(HbcContext);

  if (!context) {
    throw new Error("useHbcStore must be used inside HbcProvider");
  }

  return context;
}
