import { useState } from "react";
import { ActivityIndicator, Alert, Pressable, ScrollView, Text, TextInput, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { createCaretaker, createNurse, createPhysiotherapist, type HbcRegistrationPayload } from "../../../api/registration";

type HbcType = "NURSE" | "CARETAKER" | "PHYSIOTHERAPIST";
const serviceOptions: Record<HbcType, string[]> = {
  NURSE: ["ELDERLY_CARE"],
  CARETAKER: ["PERSONAL_HYGIENE_SUPPORT", "MEAL_PREPARATION", "COMPANIONSHIP", "MOBILITY_ASSISTANCE", "MEDICATION_REMINDERS", "HOUSEHOLD_HELP", "ERRAND_SERVICES", "MONITORING_AND_REPORTING"],
  PHYSIOTHERAPIST: ["REHABILITATION_THERAPY", "PAIN_MANAGEMENT", "MOBILITY_TRAINING", "EXERCISE_PRESCRIPTION", "ORTHOPEDIC_SUPPORT", "MONITORING_AND_PROGRESS_TRACKING"],
};
const titleByType: Record<HbcType, string> = { NURSE: "Nurse Registration", CARETAKER: "Caretaker Registration", PHYSIOTHERAPIST: "Physiotherapist Registration" };
const styles = {
  page: { flex: 1, backgroundColor: "#F7F9FC" }, content: { padding: 22, paddingBottom: 40 },
  back: { color: "#173FD1", fontSize: 16, fontWeight: "700" as const }, eyebrow: { color: "#173FD1", fontSize: 12, fontWeight: "800" as const, letterSpacing: 1.2, marginTop: 18 },
  title: { marginTop: 8, fontSize: 28, fontWeight: "800" as const, color: "#152238" }, subtitle: { marginTop: 8, color: "#657187", lineHeight: 21 },
  card: { marginTop: 22, backgroundColor: "#fff", borderRadius: 18, padding: 17, borderWidth: 1, borderColor: "#E6EAF1" },
  label: { color: "#344054", fontSize: 13, fontWeight: "700" as const, marginTop: 13, marginBottom: 7 },
  input: { borderWidth: 1, borderColor: "#DCE2EC", borderRadius: 11, padding: 13, color: "#152238" },
  button: { marginTop: 22, backgroundColor: "#173FD1", padding: 16, borderRadius: 12, alignItems: "center" as const },
  buttonText: { color: "#fff", fontSize: 15, fontWeight: "800" as const }, error: { color: "#B42318", marginTop: 12 },
} as const;

export default function HBCProviderRegistration({ navigation, route }: any) {
  const rawType = String(route?.params?.providerType || route?.params?.subtype || "NURSE").toUpperCase();
  const providerType: HbcType = rawType.includes("PHYSIO") ? "PHYSIOTHERAPIST" : rawType.includes("CARE") || rawType.includes("GENERAL") ? "CARETAKER" : "NURSE";
  const services = serviceOptions[providerType];
  const [form, setForm] = useState({ fullName: "", phone: "", address: "", qualification: "", yearsExperience: "", specialization: "", jobType: "FULL_TIME", serviceablePinCodes: "", latitude: "13.0827", longitude: "80.2707" });
  const [selectedServices, setSelectedServices] = useState<string[]>([services[0]]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const setField = (key: keyof typeof form, value: string) => setForm(previous => ({ ...previous, [key]: value }));
  const toggleService = (service: string) => setSelectedServices(previous => previous.includes(service) ? previous.filter(item => item !== service) : [...previous, service]);

  const submit = async () => {
    if (!form.fullName.trim() || !form.phone.trim() || !form.qualification.trim() || !form.specialization.trim() || !form.serviceablePinCodes.trim() || selectedServices.length === 0) {
      setError("Complete all required fields and choose at least one service."); return;
    }
    const payload: HbcRegistrationPayload = {
      fullName: form.fullName.trim(), phone: form.phone.trim(), address: form.address.trim(),
      qualification: form.qualification.trim(), yearsExperience: Number(form.yearsExperience) || 0, specialization: form.specialization.trim(),
      jobType: form.jobType, serviceablePinCodes: form.serviceablePinCodes.split(",").map(item => item.trim()).filter(Boolean),
      latitude: Number(form.latitude) || 0, longitude: Number(form.longitude) || 0, supportedServices: selectedServices, status: "AVAILABLE",
    };
    try {
      setLoading(true); setError("");
      if (providerType === "NURSE") await createNurse(payload);
      else if (providerType === "CARETAKER") await createCaretaker(payload);
      else await createPhysiotherapist(payload);
      Alert.alert("Registration submitted", `Your ${providerType === "CARETAKER" ? "caretaker" : providerType.toLowerCase()} profile has been submitted.`, [{ text: "Continue", onPress: () => navigation.replace("PendingApproval") }]);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Unable to submit registration.");
    } finally { setLoading(false); }
  };

  const field = (label: string, key: keyof typeof form, keyboardType?: "default" | "phone-pad" | "email-address" | "number-pad" | "decimal-pad", required = true) => (
    <View key={key}><Text style={styles.label}>{label}{required ? " *" : " (optional)"}</Text><TextInput value={form[key]} onChangeText={value => setField(key, value)} placeholder={label} keyboardType={keyboardType || "default"} editable={!loading} style={styles.input} /></View>
  );

  return <SafeAreaView style={styles.page}><ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
    <Pressable onPress={() => navigation.goBack()}><Text style={styles.back}>‹  Back</Text></Pressable>
    <Text style={styles.eyebrow}>UYIR · HOME-BASED CARE</Text><Text style={styles.title}>{titleByType[providerType]}</Text>
    <Text style={styles.subtitle}>Enter your details and select the services you provide. Your selected care type determines the registration endpoint.</Text>
    <View style={styles.card}>
      {field("Full name", "fullName")}{field("Mobile number", "phone", "phone-pad")}{field("Address", "address", "default", false)}
      {field("Qualification", "qualification")}{field("Years of experience", "yearsExperience", "number-pad", false)}{field("Specialization", "specialization")}{field("Serviceable PIN codes (comma separated)", "serviceablePinCodes")}
      {field("Latitude", "latitude", "decimal-pad", false)}{field("Longitude", "longitude", "decimal-pad", false)}
      <Text style={styles.label}>Job type *</Text><View style={{ flexDirection: "row", gap: 8 }}><Pressable onPress={() => setField("jobType", "FULL_TIME")} style={{ padding: 10, borderRadius: 10, borderWidth: 1, borderColor: form.jobType === "FULL_TIME" ? "#173FD1" : "#DCE2EC", backgroundColor: form.jobType === "FULL_TIME" ? "#EAF0FF" : "#fff" }}><Text style={{ color: "#344054" }}>Full time</Text></Pressable></View>
      <Text style={styles.label}>Services offered *</Text><View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>{services.map(service => <Pressable key={service} onPress={() => toggleService(service)} style={{ padding: 9, borderRadius: 18, borderWidth: 1, borderColor: selectedServices.includes(service) ? "#173FD1" : "#DCE2EC", backgroundColor: selectedServices.includes(service) ? "#EAF0FF" : "#fff" }}><Text style={{ color: "#344054", fontSize: 12 }}>{service.replace(/_/g, " ")}</Text></Pressable>)}</View>
      {error ? <Text style={styles.error}>{error}</Text> : null}
      <Pressable onPress={submit} disabled={loading} style={[styles.button, loading && { opacity: 0.6 }]}>{loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Submit registration</Text>}</Pressable>
    </View>
  </ScrollView></SafeAreaView>;
}
