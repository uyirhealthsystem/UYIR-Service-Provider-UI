import { Pressable, ScrollView, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
export default function HBCRegistrationType({ navigation, route }: any) {
  const options = [
    { name: "Nurse", desc: "Nursing and clinical home care", providerType: "NURSE" },
    { name: "General Care / Caretaker", desc: "Daily living support and personal care", providerType: "CARETAKER" },
    { name: "Physiotherapist", desc: "Physiotherapy and rehabilitation", providerType: "PHYSIOTHERAPIST" },
  ];
  return <SafeAreaView style={{ flex: 1, backgroundColor: "#F7F9FC" }}><ScrollView contentContainerStyle={{ padding: 22 }}>
    <Text style={{ color: "#173FD1", fontSize: 12, fontWeight: "800", letterSpacing: 1.2, marginTop: 18 }}>UYIR · HOME-BASED CARE</Text>
    <Text style={{ fontSize: 28, fontWeight: "800", color: "#152238", marginTop: 8 }}>Choose your care service</Text>
    <Text style={{ color: "#657187", lineHeight: 21, marginTop: 8 }}>The same registration fields are used for each care type; available services and the submission endpoint change by selection.</Text>
    <View style={{ marginTop: 22, gap: 12 }}>{options.map(option => <Pressable key={option.providerType} onPress={() => navigation.navigate("HBCProviderRegistration", { ...route?.params, providerType: option.providerType })} style={{ backgroundColor: "#fff", borderWidth: 1, borderColor: "#E6EAF1", borderRadius: 16, padding: 18 }}>
      <Text style={{ fontSize: 16, fontWeight: "800", color: "#152238" }}>{option.name}</Text><Text style={{ marginTop: 5, color: "#657187" }}>{option.desc}</Text><Text style={{ marginTop: 12, color: "#173FD1", fontWeight: "800" }}>Register →</Text>
    </Pressable>)}</View>
  </ScrollView></SafeAreaView>;
}
