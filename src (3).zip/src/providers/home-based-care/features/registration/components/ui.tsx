import { Ionicons } from "@expo/vector-icons";
import { Pressable, Text, View } from "react-native";
import type { ReactNode } from "react";

export const BLUE = "#173FD1";
export const BG = "#F6F8FC";
export const TEXT = "#172033";
export const GREEN = "#16A765";

export function Header({ title, onBack }: { title: string; onBack?: () => void }) {
  return (
    <View style={{ height: 54, paddingHorizontal: 18, flexDirection: "row", alignItems: "center", borderBottomWidth: 1, borderBottomColor: "#E9EDF3", backgroundColor: "#FFFFFF" }}>
      {onBack ? <Pressable onPress={onBack} hitSlop={10} style={{ marginRight: 10 }}><Ionicons name="chevron-back" size={24} color={TEXT} /></Pressable> : <View style={{ width: 34 }} />}
      <Text style={{ flex: 1, textAlign: "center", fontSize: 17, fontWeight: "900", color: TEXT }}>{title}</Text>
      <View style={{ width: 34 }} />
    </View>
  );
}

export function BookingCard({ booking, onPress, action }: { booking: any; onPress: () => void; action?: ReactNode }) {
  const statusLabel = booking.status === "NEW" ? "New" : booking.status === "COMPLETED" ? "Completed" : booking.status === "IN_PROGRESS" ? "In Progress" : "Accepted";
  const statusBg = booking.status === "NEW" ? "#FFECEF" : booking.status === "COMPLETED" ? "#E8FAF1" : "#EAF1FF";
  const statusColor = booking.status === "NEW" ? "#E83D52" : booking.status === "COMPLETED" ? GREEN : BLUE;

  return (
    <Pressable onPress={onPress} style={({ pressed }) => ({ backgroundColor: "#FFFFFF", borderRadius: 16, padding: 14, marginBottom: 11, borderWidth: 1, borderColor: "#E7EBF2", opacity: pressed ? 0.88 : 1 })}>
      <View style={{ flexDirection: "row", alignItems: "center" }}>
        <View style={{ width: 46, height: 46, borderRadius: 23, backgroundColor: "#EAF1FF", alignItems: "center", justifyContent: "center" }}>
          <Ionicons name="person" size={22} color={BLUE} />
        </View>
        <View style={{ flex: 1, marginLeft: 11 }}>
          <Text style={{ fontSize: 14, fontWeight: "900", color: TEXT }}>{booking.patient}</Text>
          <Text style={{ marginTop: 3, fontSize: 11, color: "#697386" }}>{booking.service}</Text>
        </View>
        <View style={{ paddingHorizontal: 8, paddingVertical: 5, borderRadius: 9, backgroundColor: statusBg }}>
          <Text style={{ fontSize: 9.5, fontWeight: "900", color: statusColor }}>{statusLabel}</Text>
        </View>
      </View>
      <View style={{ flexDirection: "row", marginTop: 12, gap: 12 }}>
        <Info icon="calendar-outline" text={`${booking.date}, ${booking.time}`} />
        <Info icon="location-outline" text={booking.distance} />
      </View>
      {action ? <View style={{ marginTop: 12 }}>{action}</View> : null}
    </Pressable>
  );
}

function Info({ icon, text }: { icon: any; text: string }) {
  return <View style={{ flexDirection: "row", alignItems: "center", flex: 1 }}><Ionicons name={icon} size={14} color={BLUE} /><Text numberOfLines={1} style={{ marginLeft: 5, fontSize: 10.5, color: "#697386", fontWeight: "600" }}>{text}</Text></View>;
}

export function Button({ title, onPress, variant = "primary" }: { title: string; onPress: () => void; variant?: "primary" | "outline" | "danger" }) {
  const primary = variant === "primary";
  const danger = variant === "danger";
  return <Pressable onPress={onPress} style={({ pressed }) => ({ flex: 1, minHeight: 46, borderRadius: 12, alignItems: "center", justifyContent: "center", backgroundColor: primary ? BLUE : "#FFFFFF", borderWidth: primary ? 0 : 1.2, borderColor: danger ? "#EE4254" : BLUE, opacity: pressed ? 0.82 : 1 })}><Text style={{ color: primary ? "#FFFFFF" : danger ? "#EE4254" : BLUE, fontWeight: "900", fontSize: 13 }}>{title}</Text></Pressable>;
}
