export type HbcProviderType =
  | "NURSE"
  | "CARETAKER"
  | "PHYSIOTHERAPIST";

export type BookingStatus =
  | "OFFERED"
  | "ACCEPTED"
  | "IN_PROGRESS"
  | "COMPLETED"
  | "CANCELLED";

export type HbcBooking = {
  id: string;
  patient: string;
  age?: number;
  gender?: string;
  service: string;
  date: string;
  time: string;
  duration: string;
  address: string;
  distance: string;
  notes: string;
  amount: number;
  status: BookingStatus | string;
  patientPhone?: string;
  raw: any;
};

export type HbcDashboard = {
  bookings: {
    total: number;
    upcoming: number;
    inProgress: number;
    completed: number;
    cancelled: number;
  };
  todayEarnings: {
    amount: number;
    completedVisits: number;
  };
  monthlyEarnings: {
    amount: number;
  };
  lifetimeEarnings?: {
    amount: number;
  };
  raw: any;
};

export type HbcProfile = {
  id: string;
  name: string;
  phone?: string;
  email?: string;
  address?: string;
  qualification?: string;
  specialization?: string;
  providerType?: string;
  status?: string;
  raw: any;
};
