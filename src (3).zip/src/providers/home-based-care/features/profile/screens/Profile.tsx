import { Ionicons } from "@expo/vector-icons";
import { useFocusEffect } from "@react-navigation/native";
import { useCallback, useState } from "react";
import { Alert, Pressable, ScrollView, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useAuth } from "../../../../../auth/store";
import { getNurseProfile, getCaretakerProfile, getPhysiotherapistProfile } from "../../../api/profile";
import { useHbcStore } from "../../provider-state/store";
import LanguageSelector from "../../../../../language/components/LanguageSelector";

const BLUE = "#0878F9";
const INK = "#10264D";
const MUTED = "#71809A";

export default function Profile() {
  const { providerId, providerType, profile: contextProfile, loading: identityLoading, error: identityError } = useHbcStore();
  const { logout } = useAuth();
  const [profile, setProfile] = useState<any>(contextProfile || null);
  const [error, setError] = useState("");

  const load = async () => {
    if (!providerId) return;
    try {
      setError("");
      const response = providerType === "NURSE" ? await getNurseProfile() : providerType === "CARETAKER" ? await getCaretakerProfile() : await getPhysiotherapistProfile();
      setProfile(response?.data?.data ?? response?.data ?? response);
    } catch (e: any) {
      setError(e?.message || "Unable to load profile.");
    }
  };
  useFocusEffect(useCallback(() => { load(); }, [providerId, providerType]));
  const data = profile || contextProfile || {};
  const name = data?.fullName || data?.name || data?.provider?.name || "Care Provider";
  const providerNumber = data?.nurseId || data?.caretakerId || data?.physiotherapistId || data?.id || providerId;
  const status = String(data?.status || "REGISTERED").toUpperCase();
  const initials = name.split(" ").filter(Boolean).slice(0, 2).map((x: string) => x[0]).join("").toUpperCase();
  const item = (icon: any, title: string, subtitle: string, onPress?: () => void, danger = false) => (
    <Pressable onPress={onPress} style={{ minHeight: 65, paddingHorizontal: 15, flexDirection: "row", alignItems: "center", borderBottomWidth: 1, borderBottomColor: "#EEF2F8" }}>
      <View style={{ width: 39, height: 39, borderRadius: 13, backgroundColor: danger ? "#FFF0F1" : "#EAF3FF", alignItems: "center", justifyContent: "center" }}><Ionicons name={icon} size={19} color={danger ? "#E63D52" : BLUE} /></View>
      <View style={{ flex: 1, marginLeft: 12 }}><Text style={{ color: danger ? "#D83248" : INK, fontSize: 13, fontWeight: "800" }}>{title}</Text>{subtitle ? <Text style={{ color: MUTED, fontSize: 10, marginTop: 3 }}>{subtitle}</Text> : null}</View>
      {!danger ? <Ionicons name="chevron-forward" size={17} color="#9AA8BB" /> : null}
    </Pressable>
  );

  return <SafeAreaView style={{ flex: 1, backgroundColor: "#F4F7FC" }} edges={["top"]}>
    <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 25 }}>
      <View style={{ paddingHorizontal: 20, paddingTop: 19, paddingBottom: 22, backgroundColor: "#FFFFFF", borderBottomLeftRadius: 25, borderBottomRightRadius: 25 }}>
        <Text style={{ color: INK, fontSize: 24, fontWeight: "900" }}>Profile</Text>
        <Text style={{ color: MUTED, fontSize: 12, marginTop: 4 }}>Your provider details and preferences</Text>
        <View style={{ marginTop: 19, borderRadius: 19, padding: 16, backgroundColor: BLUE, flexDirection: "row", alignItems: "center" }}>
          <View style={{ width: 61, height: 61, borderRadius: 20, backgroundColor: "#FFFFFF", alignItems: "center", justifyContent: "center" }}><Text style={{ color: BLUE, fontSize: 21, fontWeight: "900" }}>{initials || "H"}</Text></View>
          <View style={{ flex: 1, marginLeft: 13 }}>
            <Text style={{ color: "#FFFFFF", fontSize: 17, fontWeight: "900" }}>{name}</Text>
            <Text style={{ color: "#DDEBFF", fontSize: 11, marginTop: 4 }}>{providerType === "NURSE" ? "Nursing Care" : providerType === "PHYSIOTHERAPIST" ? "Physiotherapy" : "General Care"}</Text>
            <Text style={{ color: "#DDEBFF", fontSize: 10, marginTop: 4 }}>Provider ID: {providerNumber || "—"}</Text>
          </View>
          <View style={{ backgroundColor: "#D9FBEA", borderRadius: 9, paddingHorizontal: 8, paddingVertical: 6 }}><Text style={{ color: "#078450", fontSize: 9, fontWeight: "900" }}>{status}</Text></View>
        </View>
      </View>
      {identityError || error ? <View style={{ margin: 16, backgroundColor: "#FFF0F0", borderRadius: 12, padding: 12 }}><Text style={{ color: "#C83348", fontSize: 12 }}>{identityError || error}</Text></View> : null}
      <Text style={{ marginHorizontal: 18, marginTop: 21, marginBottom: 9, color: MUTED, fontSize: 10, fontWeight: "900", letterSpacing: 1 }}>PROVIDER INFORMATION</Text>
      <View style={{ marginHorizontal: 16, backgroundColor: "#FFFFFF", borderRadius: 17, overflow: "hidden" }}>
        {item("person-outline", "Full name", name)}
        {item("call-outline", "Phone number", data?.phone || data?.mobile || data?.mobileNumber || "Not provided")}
        {item("mail-outline", "Email address", data?.email || "Not provided")}
        {item("location-outline", "Address", data?.address || data?.fullAddress || "Not provided")}
      </View>
      <Text style={{ marginHorizontal: 18, marginTop: 21, marginBottom: 9, color: MUTED, fontSize: 10, fontWeight: "900", letterSpacing: 1 }}>APP SETTINGS</Text>
      <View style={{ marginHorizontal: 16, backgroundColor: "#FFFFFF", borderRadius: 17, overflow: "hidden" }}>
        <View style={{ minHeight: 68, paddingHorizontal: 15, flexDirection: "row", alignItems: "center" }}>
          <View style={{ width: 39, height: 39, borderRadius: 13, backgroundColor: "#EAF3FF", alignItems: "center", justifyContent: "center" }}><Ionicons name="language-outline" size={19} color={BLUE} /></View>
          <View style={{ flex: 1, marginLeft: 12 }}><Text style={{ color: INK, fontSize: 13, fontWeight: "800" }}>Language</Text><Text style={{ color: MUTED, fontSize: 10, marginTop: 3 }}>Choose app language</Text></View>
          <LanguageSelector />
        </View>
        {item("help-circle-outline", "Help & support", "Get assistance")}
        {item("information-circle-outline", "About Uyir", "Home-Based Care Provider")}
        {item("log-out-outline", "Logout", "Sign out of your provider account", () => Alert.alert("Logout", "Are you sure you want to log out?", [{ text: "Stay", style: "cancel" }, { text: "Logout", style: "destructive", onPress: logout }]), true)}
      </View>
      {identityLoading ? <Text style={{ textAlign: "center", color: MUTED, fontSize: 11, marginTop: 12 }}>Refreshing provider details…</Text> : null}
    </ScrollView>
  </SafeAreaView>;
}
