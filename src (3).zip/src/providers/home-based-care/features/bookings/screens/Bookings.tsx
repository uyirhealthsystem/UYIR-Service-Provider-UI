import { Ionicons } from "@expo/vector-icons";
import { useFocusEffect } from "@react-navigation/native";
import { useCallback, useState } from "react";
import { Alert, Pressable, RefreshControl, ScrollView, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { acceptBooking, getServicePool } from "../../../api/bookings";
import { getBookingHistory } from "../../../api/dashboard";
import { useHbcStore } from "../../provider-state/store";

const BLUE = "#0878F9";
const INK = "#10264D";
const MUTED = "#71809A";
const FILTERS = [
  { key: "OFFERED", label: "Available" },
  { key: "ACCEPTED", label: "Picked" },
  { key: "IN_PROGRESS", label: "In Progress" },
  { key: "COMPLETED", label: "Completed" },
  { key: "CANCELLED", label: "Cancelled" },
];
function rowsOf(response: any): any[] {
  const data = response?.data?.data ?? response?.data ?? response;
  const list = data?.content ?? data?.bookings ?? data?.items ?? data?.results ?? data;
  return Array.isArray(list) ? list : [];
}
function idOf(b: any) { return String(b?.bookingId ?? b?.id ?? ""); }
function nameOf(b: any) { return b?.patientName ?? b?.patient?.name ?? b?.userName ?? "Patient"; }
function serviceOf(b: any) { return b?.serviceName ?? b?.serviceType ?? b?.serviceCode ?? b?.careType ?? "Home-Based Care"; }
export default function Bookings({ navigation }: any) {
  const { providerId } = useHbcStore();
  const [filter, setFilter] = useState("OFFERED");
  const [list, setList] = useState<any[]>([]);
  const [pickedCount, setPickedCount] = useState(0);
  const [busyId, setBusyId] = useState("");
  const [error, setError] = useState("");
  const [refreshing, setRefreshing] = useState(false);

  const load = async () => {
    if (!providerId) return;
    setRefreshing(true); setError("");
    try {
      const [response, accepted, progress] = await Promise.all([
        filter === "COMPLETED" || filter === "CANCELLED"
          ? getBookingHistory(providerId, filter)
          : getServicePool(providerId, filter),
        getServicePool(providerId, "ACCEPTED").catch(() => null),
        getServicePool(providerId, "IN_PROGRESS").catch(() => null),
      ]);
      const current = rowsOf(response);
      setList(current);
      const acceptedRows = rowsOf(accepted);
      const progressRows = rowsOf(progress);
      const unique = new Set([...acceptedRows, ...progressRows].map(idOf).filter(Boolean));
      setPickedCount(unique.size);
    } catch (e: any) { setError(e?.message || "Unable to load bookings."); }
    finally { setRefreshing(false); }
  };
  useFocusEffect(useCallback(() => { load(); }, [providerId, filter]));

  const open = (booking: any) => navigation.navigate("HomeCareBookingDetails", {
    bookingId: idOf(booking), booking, picked: ["ACCEPTED", "CONFIRMED", "IN_PROGRESS", "STARTED"].includes(String(booking?.status || filter).toUpperCase()), hasActiveBooking: pickedCount >= 5,
  });
  const pick = async (booking: any) => {
    if (pickedCount >= 5) {
      Alert.alert("5 bookings already picked", "Complete a service before picking another booking.");
      return;
    }
    const id = idOf(booking);
    if (!id) { Alert.alert("Booking ID missing", "The API response did not include a booking ID."); return; }
    setBusyId(id);
    try {
      await acceptBooking(id, providerId);
      Alert.alert("Booking picked", "The booking has been added to your picked list.");
      setFilter("ACCEPTED");
      await load();
    } catch (e: any) { Alert.alert("Could not pick booking", e?.message || "Please try again."); }
    finally { setBusyId(""); }
  };

  return <SafeAreaView style={{ flex: 1, backgroundColor: "#F4F7FC" }} edges={["top"]}>
    <View style={{ paddingHorizontal: 18, paddingTop: 14, paddingBottom: 13, backgroundColor: "#FFFFFF", borderBottomLeftRadius: 22, borderBottomRightRadius: 22 }}>
      <Text style={{ fontSize: 23, fontWeight: "900", color: INK }}>Booking Pools</Text>
      <Text style={{ color: MUTED, fontSize: 12, marginTop: 4 }}>Pick up to 5 bookings and manage your visits.</Text>
      <View style={{ marginTop: 14, backgroundColor: "#EAF3FF", borderRadius: 13, padding: 12, flexDirection: "row", alignItems: "center" }}>
        <Ionicons name="layers-outline" size={20} color={BLUE} />
        <View style={{ flex: 1, marginLeft: 9 }}><Text style={{ color: INK, fontWeight: "900", fontSize: 12 }}>Picked booking capacity</Text><Text style={{ color: MUTED, fontSize: 10, marginTop: 3 }}>{pickedCount} of 5 selected · {Math.max(0, 5 - pickedCount)} slots remaining</Text></View>
        <Text style={{ color: BLUE, fontWeight: "900", fontSize: 15 }}>{pickedCount}/5</Text>
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 14 }} contentContainerStyle={{ gap: 7 }}>
        {FILTERS.map(item => <Pressable key={item.key} onPress={() => setFilter(item.key)} style={{ paddingHorizontal: 13, paddingVertical: 9, borderRadius: 10, backgroundColor: filter === item.key ? BLUE : "#F0F4FA" }}><Text style={{ color: filter === item.key ? "#FFFFFF" : MUTED, fontSize: 11, fontWeight: "800" }}>{item.label}</Text></Pressable>)}
      </ScrollView>
    </View>
    {error ? <View style={{ margin: 16, padding: 13, borderRadius: 12, backgroundColor: "#FFF0F0" }}><Text style={{ color: "#C83348", fontSize: 12 }}>{error}</Text><Pressable onPress={load} style={{ marginTop: 7 }}><Text style={{ color: BLUE, fontWeight: "800" }}>Retry</Text></Pressable></View> : null}
    <ScrollView refreshControl={<RefreshControl refreshing={refreshing} onRefresh={load} tintColor={BLUE} />} contentContainerStyle={{ padding: 15, paddingBottom: 30 }}>
      {list.map((b: any) => {
        const id = idOf(b);
        const offered = filter === "OFFERED";
        return <View key={id || `${nameOf(b)}-${b?.startTime}`} style={{ backgroundColor: "#FFFFFF", borderRadius: 17, padding: 14, marginBottom: 11, borderWidth: 1, borderColor: "#E7EDF7" }}>
          <Pressable onPress={() => open(b)} style={{ flexDirection: "row", alignItems: "center" }}>
            <View style={{ width: 46, height: 46, borderRadius: 15, backgroundColor: "#EAF3FF", alignItems: "center", justifyContent: "center" }}><Text style={{ color: BLUE, fontWeight: "900" }}>{nameOf(b).split(" ").map((x: string) => x[0]).slice(0,2).join("").toUpperCase()}</Text></View>
            <View style={{ flex: 1, marginLeft: 11 }}>
              <Text style={{ fontSize: 13, fontWeight: "900", color: INK }}>{nameOf(b)}</Text>
              <Text style={{ marginTop: 3, fontSize: 11, color: MUTED }}>{serviceOf(b)}</Text>
              <Text style={{ marginTop: 4, fontSize: 10, color: MUTED }}>{b?.appointmentDate || b?.startDate || b?.date || "Date not specified"} · {b?.startTime || b?.time || "Time not specified"}</Text>
              <Text numberOfLines={2} style={{ marginTop: 4, fontSize: 10, color: MUTED }}>{b?.serviceAddress || b?.address || b?.patientAddress || "Home visit"}</Text>
            </View>
            <Ionicons name="chevron-forward" size={18} color="#9AA8BB" />
          </Pressable>
          <View style={{ marginTop: 12, flexDirection: "row", gap: 9 }}>
            <Pressable onPress={() => open(b)} style={{ flex: 1, height: 40, borderRadius: 11, borderWidth: 1, borderColor: "#DCE7F8", alignItems: "center", justifyContent: "center" }}><Text style={{ color: BLUE, fontWeight: "800", fontSize: 11 }}>Patient details</Text></Pressable>
            {offered ? <Pressable disabled={!!busyId || pickedCount >= 5} onPress={() => pick(b)} style={{ flex: 1, height: 40, borderRadius: 11, backgroundColor: pickedCount >= 5 ? "#AAB7CD" : BLUE, alignItems: "center", justifyContent: "center" }}><Text style={{ color: "#FFFFFF", fontWeight: "900", fontSize: 11 }}>{busyId === id ? "Picking…" : "Pick booking"}</Text></Pressable> : null}
          </View>
        </View>;
      })}
      {!refreshing && !list.length ? <View style={{ alignItems: "center", padding: 34, backgroundColor: "#FFFFFF", borderRadius: 17 }}><Ionicons name="file-tray-outline" size={32} color="#9AA8BB" /><Text style={{ color: INK, fontWeight: "900", marginTop: 10 }}>No {FILTERS.find(x => x.key === filter)?.label.toLowerCase()} bookings</Text><Text style={{ color: MUTED, fontSize: 11, textAlign: "center", marginTop: 5 }}>Pull down to refresh this list.</Text></View> : null}
    </ScrollView>
  </SafeAreaView>;
}
