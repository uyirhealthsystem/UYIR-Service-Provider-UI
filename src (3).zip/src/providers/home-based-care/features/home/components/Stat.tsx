import { Ionicons } from "@expo/vector-icons";
import { Text, View } from "react-native";
export default function Stat({ value, label, icon, green }: any) { return <View style={{ flex: 1, alignItems: "center" }}><Ionicons name={icon} size={18} color={green ? "#16A765" : "#173FD1"} /><Text style={{ color: green ? "#16A765" : "#173FD1", fontSize: 15, fontWeight: "900", marginTop: 4 }}>{value}</Text><Text style={{ color: "#7B8190", fontSize: 7.5, textAlign: "center", marginTop: 2 }}>{label}</Text></View>; }
