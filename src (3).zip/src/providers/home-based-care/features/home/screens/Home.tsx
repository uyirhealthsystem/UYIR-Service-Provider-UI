import { Ionicons } from "@expo/vector-icons";
import { useFocusEffect } from "@react-navigation/native";
import { useCallback, useState } from "react";
import { Alert, Pressable, RefreshControl, ScrollView, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { getDashboard } from "../../../api/dashboard";
import { acceptBooking, getServicePool } from "../../../api/bookings";
import { useHbcStore } from "../../provider-state/store";

const BLUE = "#0878F9";
const INK = "#10264D";
const MUTED = "#71809A";
const BG = "#F4F7FC";

function getRows(response: any): any[] {
  const data = response?.data?.data ?? response?.data ?? response;
  const rows = data?.content ?? data?.bookings ?? data?.items ?? data?.results ?? data;
  return Array.isArray(rows) ? rows : [];
}
function keyOf(item: any) { return String(item?.bookingId ?? item?.id ?? item?.booking?.id ?? ""); }
function labelOf(item: any) {
  return item?.patientName ?? item?.patient?.name ?? item?.userName ?? item?.patient?.fullName ?? "Patient";
}
function serviceOf(item: any) {
  return item?.serviceName ?? item?.serviceType ?? item?.serviceCode ?? item?.careType ?? "Home-Based Care";
}
function card(title: string, value: string, icon: any, tint: string) {
  return { title, value, icon, tint };
}

export default function Home({ navigation }: any) {
  const { providerId, providerType, profile, loading: identityLoading, error: identityError } = useHbcStore();
  const [dashboard, setDashboard] = useState<any>(null);
  const [offered, setOffered] = useState<any[]>([]);
  const [picked, setPicked] = useState<any[]>([]);
  const [progress, setProgress] = useState<any[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [busyId, setBusyId] = useState("");
  const [error, setError] = useState("");

  const load = async () => {
    if (!providerId) return;
    setRefreshing(true); setError("");
    try {
      const results = await Promise.all([
        getDashboard(providerId).catch(() => null),
        getServicePool(providerId, "OFFERED"),
        getServicePool(providerId, "ACCEPTED"),
        getServicePool(providerId, "IN_PROGRESS").catch(() => null),
        getServicePool(providerId, "COMPLETED").catch(() => null),
      ]);
      const dash = results[0]?.data?.data ?? results[0]?.data ?? results[0];
      setDashboard(dash || null);
      setOffered(getRows(results[1]));
      const acceptedRows = getRows(results[2]);
      const progressRows = getRows(results[3]);
      const completedRows = getRows(results[4]);
      const unique = new Map<string, any>();
      [...acceptedRows, ...progressRows].forEach((b: any) => {
        const k = keyOf(b); if (k) unique.set(k, b);
      });
      setPicked([...unique.values()].filter((b: any) => !["COMPLETED", "CANCELLED"].includes(String(b.status || "").toUpperCase())));
      setProgress(progressRows);
      if (!results[0]) setDashboard(null);
      // Keep completed count from the API pool if dashboard summary omits it.
      setDashboard((current: any) => ({ ...(current || dash || {}), _completedPoolCount: completedRows.length }));
    } catch (e: any) {
      setError(e?.message || "Unable to load booking pools. Please retry.");
    } finally { setRefreshing(false); }
  };
  useFocusEffect(useCallback(() => { load(); }, [providerId, providerType]));

  const activeCount = picked.length;
  const capacity = Math.max(0, 5 - activeCount);
  const providerName = profile?.fullName || profile?.name || dashboard?.provider?.fullName || dashboard?.provider?.name || dashboard?.nurse?.fullName || dashboard?.caretaker?.fullName || dashboard?.physiotherapist?.fullName || "Care Provider";
  const counts = dashboard?.bookings || dashboard?.counts || dashboard?.data?.bookings || dashboard?.data?.counts || {};
  const completed = counts?.completed ?? counts?.completedBookings ?? dashboard?._completedPoolCount ?? 0;
  const inProgress = counts?.inProgress ?? progress.length;
  const today = counts?.today ?? counts?.todayBookings ?? offered.length + picked.length;
  const poolTitle = providerType === "NURSE" ? "Nursing Care" : providerType === "PHYSIOTHERAPIST" ? "Physiotherapy" : "General Care";
  const poolIcon = providerType === "NURSE" ? "medkit" : providerType === "PHYSIOTHERAPIST" ? "body" : "heart";
  const doPick = async (booking: any) => {
    const id = keyOf(booking);
    if (!id) { Alert.alert("Booking ID missing", "This booking has no ID from the API."); return; }
    if (activeCount >= 5) { Alert.alert("Pick limit reached", "You have 5 picked bookings. Complete a service before picking another."); return; }
    setBusyId(id);
    try {
      await acceptBooking(id, providerId);
      Alert.alert("Booking picked", `${labelOf(booking)} has been added to your picked bookings.`);
      await load();
    } catch (e: any) {
      Alert.alert("Unable to pick booking", e?.message || "The booking could not be accepted.");
    } finally { setBusyId(""); }
  };
  const openDetails = (booking: any) => navigation.navigate("HomeCareBookingDetails", { bookingId: keyOf(booking), booking, picked: ["ACCEPTED", "CONFIRMED", "IN_PROGRESS", "STARTED"].includes(String(booking?.status || "").toUpperCase()), hasActiveBooking: activeCount >= 5 });

  const Stat = ({ value, label, icon, tint }: any) => (
    <View style={{ flex: 1, backgroundColor: "#FFFFFF", borderRadius: 16, padding: 12, minHeight: 92, borderWidth: 1, borderColor: "#EAF0F8" }}>
      <View style={{ width: 30, height: 30, borderRadius: 10, backgroundColor: tint + "18", alignItems: "center", justifyContent: "center" }}><Ionicons name={icon} size={17} color={tint} /></View>
      <Text style={{ fontSize: 21, fontWeight: "900", color: INK, marginTop: 8 }}>{value}</Text>
      <Text style={{ fontSize: 10, color: MUTED, marginTop: 2 }}>{label}</Text>
    </View>
  );
  const BookingCard = ({ booking }: any) => {
    const id = keyOf(booking);
    return <View style={{ backgroundColor: "#FFFFFF", borderRadius: 17, padding: 13, marginBottom: 10, borderWidth: 1, borderColor: "#E8EEF7" }}>
      <Pressable onPress={() => openDetails(booking)} style={{ flexDirection: "row", alignItems: "center" }}>
        <View style={{ width: 44, height: 44, borderRadius: 15, backgroundColor: "#EAF3FF", alignItems: "center", justifyContent: "center" }}><Text style={{ color: BLUE, fontWeight: "900", fontSize: 15 }}>{labelOf(booking).split(" ").map((x: string) => x[0]).slice(0,2).join("").toUpperCase()}</Text></View>
        <View style={{ flex: 1, marginLeft: 11 }}>
          <Text style={{ color: INK, fontWeight: "900", fontSize: 13 }}>{labelOf(booking)}</Text>
          <Text style={{ color: MUTED, fontSize: 11, marginTop: 3 }}>{serviceOf(booking)}</Text>
          <Text style={{ color: MUTED, fontSize: 10, marginTop: 4 }}>{booking?.startTime || booking?.time || booking?.appointmentTime || "Time not specified"} · {booking?.distanceKm != null ? `${booking.distanceKm} km away` : "Home visit"}</Text>
        </View>
        <Ionicons name="chevron-forward" size={18} color="#98A5B9" />
      </Pressable>
      <View style={{ flexDirection: "row", marginTop: 12, gap: 9 }}>
        <Pressable onPress={() => openDetails(booking)} style={{ flex: 1, height: 40, borderRadius: 11, borderWidth: 1, borderColor: "#DCE7F8", alignItems: "center", justifyContent: "center" }}><Text style={{ color: BLUE, fontSize: 12, fontWeight: "800" }}>View details</Text></Pressable>
        <Pressable disabled={!!busyId || activeCount >= 5} onPress={() => doPick(booking)} style={{ flex: 1, height: 40, borderRadius: 11, backgroundColor: activeCount >= 5 ? "#AAB7CD" : BLUE, alignItems: "center", justifyContent: "center" }}><Text style={{ color: "#FFFFFF", fontSize: 12, fontWeight: "900" }}>{busyId === id ? "Picking..." : "Pick booking"}</Text></Pressable>
      </View>
    </View>;
  };

  return <SafeAreaView style={{ flex: 1, backgroundColor: BG }} edges={["top"]}>
    <ScrollView showsVerticalScrollIndicator={false} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={load} tintColor={BLUE} />} contentContainerStyle={{ paddingBottom: 26 }}>
      <View style={{ backgroundColor: BLUE, paddingHorizontal: 20, paddingTop: 16, paddingBottom: 25, borderBottomLeftRadius: 28, borderBottomRightRadius: 28 }}>
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <View style={{ width: 45, height: 45, borderRadius: 15, backgroundColor: "#FFFFFF", alignItems: "center", justifyContent: "center" }}><Ionicons name="home" size={23} color={BLUE} /></View>
          <View style={{ flex: 1, marginLeft: 11 }}><Text style={{ color: "#DCEBFF", fontSize: 11 }}>HOME-BASED CARE</Text><Text style={{ color: "#FFFFFF", fontSize: 17, fontWeight: "900", marginTop: 3 }}>Good day, {providerName.split(" ")[0]}</Text></View>
          <Pressable onPress={() => navigation.navigate("Bookings")} style={{ padding: 8 }}><Ionicons name="notifications-outline" size={23} color="#FFFFFF" /></Pressable>
        </View>
        <Text style={{ color: "#FFFFFF", fontSize: 23, fontWeight: "900", marginTop: 23 }}>Care starts with you.</Text>
        <Text style={{ color: "#E0EDFF", fontSize: 12, marginTop: 5 }}>Choose nearby bookings and plan your visits.</Text>
        <View style={{ backgroundColor: "#FFFFFF", borderRadius: 17, padding: 14, marginTop: 18 }}>
          <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}><Text style={{ color: INK, fontWeight: "900", fontSize: 13 }}>Your picked bookings</Text><Text style={{ color: BLUE, fontWeight: "900", fontSize: 13 }}>{activeCount} / 5</Text></View>
          <View style={{ height: 7, borderRadius: 5, backgroundColor: "#E8EFF9", marginTop: 10, overflow: "hidden" }}><View style={{ width: `${Math.min(100, activeCount / 5 * 100)}%`, height: 7, borderRadius: 5, backgroundColor: "#13B77A" }} /></View>
          <Text style={{ color: MUTED, fontSize: 11, marginTop: 7 }}>{capacity ? `You can pick ${capacity} more booking${capacity === 1 ? "" : "s"}.` : "All 5 slots are filled. Complete a service to free a slot."}</Text>
        </View>
      </View>

      <View style={{ paddingHorizontal: 16, paddingTop: 17 }}>
        {(identityError || error) ? <View style={{ backgroundColor: "#FFF0F0", padding: 12, borderRadius: 12, marginBottom: 13 }}><Text style={{ color: "#C83348", fontSize: 12 }}>{identityError || error}</Text><Pressable onPress={load} style={{ marginTop: 7 }}><Text style={{ color: BLUE, fontWeight: "800" }}>Retry</Text></Pressable></View> : null}
        <View style={{ flexDirection: "row", gap: 9 }}>
          <Stat value={String(today)} label="Today's pool" icon="calendar" tint={BLUE} />
          <Stat value={String(inProgress)} label="In progress" icon="time" tint="#F59E0B" />
          <Stat value={String(completed)} label="Completed" icon="checkmark-circle" tint="#10A56A" />
        </View>

        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 23, marginBottom: 11 }}>
          <View><Text style={{ color: INK, fontSize: 17, fontWeight: "900" }}>Available Booking Pool</Text><Text style={{ color: MUTED, fontSize: 11, marginTop: 3 }}>{poolTitle} · {offered.length} available</Text></View>
          <Pressable onPress={() => navigation.navigate("Bookings")}><Text style={{ color: BLUE, fontWeight: "900", fontSize: 12 }}>View all</Text></Pressable>
        </View>
        <Pressable onPress={() => navigation.navigate("Bookings")} style={{ backgroundColor: "#FFFFFF", borderRadius: 18, padding: 15, flexDirection: "row", alignItems: "center", borderWidth: 1, borderColor: "#E6EDF8" }}>
          <View style={{ width: 48, height: 48, borderRadius: 15, backgroundColor: "#EAF3FF", alignItems: "center", justifyContent: "center" }}><Ionicons name={poolIcon as any} size={24} color={BLUE} /></View>
          <View style={{ flex: 1, marginLeft: 12 }}><Text style={{ color: INK, fontWeight: "900", fontSize: 14 }}>{poolTitle}</Text><Text style={{ color: MUTED, fontSize: 11, marginTop: 4 }}>{offered.length} bookings waiting for care</Text></View>
          <View style={{ backgroundColor: "#EAF3FF", paddingHorizontal: 12, paddingVertical: 8, borderRadius: 10 }}><Text style={{ color: BLUE, fontWeight: "900", fontSize: 11 }}>Explore</Text></View>
        </Pressable>

        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 23, marginBottom: 11 }}><Text style={{ color: INK, fontSize: 17, fontWeight: "900" }}>New in your pool</Text><Text style={{ color: MUTED, fontSize: 11 }}>{offered.length} requests</Text></View>
        {identityLoading || refreshing ? <Text style={{ color: MUTED, paddingVertical: 12 }}>Loading booking pool…</Text> : offered.slice(0,3).map((b: any) => <BookingCard key={keyOf(b)} booking={b} />)}
        {!refreshing && !offered.length ? <View style={{ alignItems: "center", padding: 24, backgroundColor: "#FFFFFF", borderRadius: 16 }}><Ionicons name="calendar-clear-outline" size={28} color="#9AA8BB" /><Text style={{ color: INK, fontWeight: "800", marginTop: 8 }}>No new bookings right now</Text><Text style={{ color: MUTED, fontSize: 11, marginTop: 4 }}>Pull down to refresh the pool.</Text></View> : null}

        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 23, marginBottom: 11 }}><Text style={{ color: INK, fontSize: 17, fontWeight: "900" }}>Picked bookings</Text><Pressable onPress={() => navigation.navigate("Bookings")}><Text style={{ color: BLUE, fontWeight: "900", fontSize: 12 }}>Open list</Text></Pressable></View>
        {picked.slice(0,3).map((b: any) => <Pressable key={keyOf(b)} onPress={() => openDetails(b)} style={{ backgroundColor: "#FFFFFF", borderRadius: 14, padding: 13, marginBottom: 9, flexDirection: "row", alignItems: "center" }}><View style={{ width: 38, height: 38, borderRadius: 13, backgroundColor: "#E5F9F0", alignItems: "center", justifyContent: "center" }}><Ionicons name="checkmark-circle" size={20} color="#10A56A" /></View><View style={{ flex: 1, marginLeft: 10 }}><Text style={{ color: INK, fontWeight: "900", fontSize: 12 }}>{labelOf(b)}</Text><Text style={{ color: MUTED, fontSize: 10, marginTop: 3 }}>{serviceOf(b)} · {String(b.status || "ACCEPTED").replace("_"," ")}</Text></View><Ionicons name="chevron-forward" size={17} color={MUTED} /></Pressable>)}
      </View>
    </ScrollView>
  </SafeAreaView>;
}
