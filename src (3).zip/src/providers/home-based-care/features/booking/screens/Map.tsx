import { Ionicons } from "@expo/vector-icons";
import { Pressable, Text, View } from "react-native";
import MapView, { Marker, UrlTile } from "react-native-maps";
import { SafeAreaView } from "react-native-safe-area-context";
import Header from "../components/Header";

export default function Map({ route, navigation }: any) {
  const booking = route.params?.booking || {};
  const bookingId = route.params?.bookingId;
  const lat = Number(booking?.latitude ?? booking?.patientLatitude ?? booking?.location?.latitude);
  const lon = Number(booking?.longitude ?? booking?.patientLongitude ?? booking?.location?.longitude);
  const hasPatientCoords = Number.isFinite(lat) && Number.isFinite(lon) && Math.abs(lat) > 0.01 && Math.abs(lon) > 0.01;

  const reached = () => {
    navigation.navigate("HomeCareBookingDetails", {
      bookingId,
      booking,
      reachedPatient: true,
    });
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#F6F8FC" }} edges={["top"]}>
      <Header title="Patient Location" onBack={() => navigation.goBack()} />
      <View style={{ flex: 1, padding: 14 }}>
        <View style={{ flex: 1, minHeight: 400, borderRadius: 20, overflow: "hidden", backgroundColor: "#E8EEF2", borderWidth: 1, borderColor: "#D7DEE5" }}>
          <MapView style={{ flex: 1 }} mapType="none" initialRegion={{ latitude: hasPatientCoords ? lat : 13.0827, longitude: hasPatientCoords ? lon : 80.2707, latitudeDelta: 0.025, longitudeDelta: 0.025 }} showsUserLocation showsMyLocationButton>
            <UrlTile urlTemplate="https://tile.openstreetmap.org/{z}/{x}/{y}.png" maximumZ={19} />
            {hasPatientCoords ? <Marker coordinate={{ latitude: lat, longitude: lon }} title="Patient" pinColor="#E83D52" /> : null}
          </MapView>
          <View style={{ position: "absolute", left: 12, top: 12, right: 12, backgroundColor: "#FFFFFFEE", borderRadius: 10, padding: 11 }}>
            <Text style={{ color: "#172033", fontWeight: "900", fontSize: 12 }}>Patient location · OpenStreetMap</Text>
            <Text style={{ color: "#7B8190", fontSize: 10, marginTop: 3 }}>{hasPatientCoords ? "Blue dot shows your current location when location permission is enabled." : "This booking has no patient GPS coordinates. Showing Chennai as a map fallback; do not use it for navigation."}</Text>
          </View>
        </View>
        <View style={{ backgroundColor: "#FFFFFF", borderRadius: 17, padding: 14, marginTop: 12 }}>
          <View style={{ flexDirection: "row", alignItems: "center" }}>
            <View style={{ width: 42, height: 42, borderRadius: 21, backgroundColor: "#FFECEF", alignItems: "center", justifyContent: "center" }}>
              <Ionicons name="person" size={19} color="#E83D52" />
            </View>
            <View style={{ flex: 1, marginLeft: 10 }}>
              <Text style={{ color: "#172033", fontWeight: "900", fontSize: 13 }}>{booking?.patientName || booking?.patient?.name || "Patient"}</Text>
              <Text style={{ color: "#7B8190", fontSize: 10, marginTop: 2 }}>{booking?.serviceAddress || booking?.address || booking?.patientAddress || "Patient location"}</Text>
            </View>
          </View>
          <Pressable onPress={reached} style={{ marginTop: 11, height: 44, borderRadius: 11, backgroundColor: "#173FD1", alignItems: "center", justifyContent: "center" }}>
            <Text style={{ color: "#FFFFFF", fontWeight: "900" }}>I Have Reached the Patient</Text>
          </Pressable>
        </View>
      </View>
    </SafeAreaView>
  );
}
