import React from "react";
import { Ionicons } from "@expo/vector-icons";
import { Alert, Pressable, ScrollView, Text, TextInput, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  acceptBooking,
  getCareDetails,
  getPrescriptions,
  getVisits,
  startVisit,
  completeVisit,
  confirmBooking,
  saveClinicalDetails,
  cancelAcceptedBooking,
  getServicePool,
} from "../../../api/bookings";
import { useHbcStore } from "../../provider-state/store";
import Header from "../components/Header";
import Button from "../components/Button";
import Detail from "../components/Detail";

export default function BookingDetails({ route, navigation }: any) {
  const { providerId } = useHbcStore();
  const bookingId = route.params?.bookingId;
  const initialBooking = route.params?.booking;
  const hasActiveBooking = Boolean(route.params?.hasActiveBooking);
  const reachedPatient = Boolean(route.params?.reachedPatient);
  const wasPicked = Boolean(route.params?.picked);

  const [booking, setBooking] = React.useState<any>(initialBooking || null);
  const [status, setStatus] = React.useState(
    String(wasPicked ? "ACCEPTED" : (initialBooking?.status || "")).toUpperCase()
  );
  const [visit, setVisit] = React.useState<any>(null);
  const [otp, setOtp] = React.useState("");
  const [notes, setNotes] = React.useState("");
  const [loading, setLoading] = React.useState(true);
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState("");

  const load = async () => {
    if (!bookingId || !providerId) {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError("");

      let item = initialBooking || booking;
      const [care, prescriptions, visitsResponse] = await Promise.all([
        getCareDetails(bookingId, providerId).catch(() => null),
        getPrescriptions(bookingId, providerId).catch(() => null),
        getVisits(bookingId).catch(() => null),
      ]);

      if (!item) {
        const poolResponse = await getServicePool(providerId, "ACCEPTED");
        const data = poolResponse?.data?.data ?? poolResponse?.data ?? poolResponse;
        const rows = data?.content ?? data?.bookings ?? data?.items ?? [];
        item = Array.isArray(rows)
          ? rows.find((row: any) => (row.bookingId || row.id) === bookingId)
          : null;
      }

      if (!item) {
        throw new Error(`Booking ${bookingId} was not found in the accepted booking pool.`);
      }

      setBooking({
        ...item,
        careDetails: care?.data?.data ?? care?.data ?? care,
        prescriptions: prescriptions?.data?.data ?? prescriptions?.data ?? prescriptions,
      });

      const nextStatus = String(wasPicked ? "ACCEPTED" : (item.status || status || "")).toUpperCase();
      setStatus(nextStatus);

      const visitData = visitsResponse?.data?.data ?? visitsResponse?.data ?? visitsResponse;
      const visitList = Array.isArray(visitData)
        ? visitData
        : visitData?.content ?? visitData?.visits ?? [];
      setVisit(visitList.find((row: any) => row.status !== "COMPLETED") || visitList[0] || null);
    } catch (loadError: any) {
      console.log("HBC booking details error:", loadError);
      setError(loadError?.message || "Unable to load booking");
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    load();
  }, [bookingId, providerId]);

  const accept = async () => {
    if (hasActiveBooking && !wasPicked) {
      Alert.alert(
        "Current booking in progress",
        "Complete your current service before accepting another booking."
      );
      return;
    }

    try {
      setBusy(true);
      const response = await acceptBooking(bookingId, providerId);
      const data = response?.data?.data ?? response?.data ?? response;
      setBooking((current: any) => ({ ...(current || {}), ...(data || {}) }));
      setStatus(String(data?.status || "ACCEPTED").toUpperCase());
      Alert.alert(
        "Booking Accepted",
        "Review the booking, then confirm it or cancel it before travelling."
      );
    } catch (e: any) {
      Alert.alert("Accept failed", e?.message || "Unable to accept booking");
    } finally {
      setBusy(false);
    }
  };

  const confirm = async () => {
    try {
      setBusy(true);
      const response = await confirmBooking(bookingId, providerId);
      const data = response?.data?.data ?? response?.data ?? response;
      setBooking((current: any) => ({ ...(current || {}), ...(data || {}) }));
      setStatus("CONFIRMED");
      Alert.alert(
        "Booking Confirmed",
        "Now go to the patient's location. The OTP step will be available after you mark that you have arrived."
      );
    } catch (e: any) {
      Alert.alert("Confirmation failed", e?.message || "Unable to confirm booking");
    } finally {
      setBusy(false);
    }
  };

  const cancel = () => {
    Alert.alert(
      "Cancel booking?",
      "Are you sure you want to cancel this accepted booking?",
      [
        { text: "Keep booking", style: "cancel" },
        {
          text: "Cancel booking",
          style: "destructive",
          onPress: async () => {
            try {
              setBusy(true);
              await cancelAcceptedBooking(bookingId, providerId, "Provider cancelled before starting service");
              setStatus("CANCELLED");
              Alert.alert("Booking Cancelled", "This booking has been cancelled.");
              navigation.goBack();
            } catch (e: any) {
              Alert.alert("Cancellation failed", e?.message || "Unable to cancel booking");
            } finally {
              setBusy(false);
            }
          },
        },
      ]
    );
  };

  const openMap = () => {
    navigation.navigate("HomeCareMap", {
      bookingId,
      booking,
    });
  };

  const start = async () => {
    if (!visit?.id) {
      Alert.alert("Visit not ready", "No visit was returned for this booking yet. Refresh the booking and try again.");
      return;
    }
    if (!otp.trim()) {
      Alert.alert("OTP required", "Enter the service OTP provided by the patient.");
      return;
    }

    try {
      setBusy(true);
      await startVisit(visit.id, providerId, otp.trim());
      setStatus("IN_PROGRESS");
      await load();
      Alert.alert("Service Started", "The visit is now in progress.");
    } catch (e: any) {
      Alert.alert("Start failed", e?.message || "Invalid service OTP");
    } finally {
      setBusy(false);
    }
  };

  const complete = async () => {
    if (!visit?.id) {
      Alert.alert("Visit not ready", "No visit was returned for this booking.");
      return;
    }

    try {
      setBusy(true);
      if (notes.trim()) {
        await saveClinicalDetails(bookingId, providerId, { careNotes: notes.trim() });
      }
      await completeVisit(visit.id, providerId);
      setStatus("COMPLETED");
      await load();
      Alert.alert("Service Completed", "You can now accept another booking.");
    } catch (e: any) {
      Alert.alert("Complete failed", e?.message || "Unable to complete visit");
    } finally {
      setBusy(false);
    }
  };

  const patientName =
    booking?.patientName || booking?.patient?.name || booking?.userName || "Patient";

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#F6F8FC" }} edges={["top"]}>
      <Header title="Booking Details" onBack={() => navigation.goBack()} />
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 30 }}>
        {loading ? (
          <Text style={{ padding: 20, color: "#697386" }}>Loading booking...</Text>
        ) : error ? (
          <View style={{ backgroundColor: "#FFF1F1", padding: 14, borderRadius: 12 }}>
            <Text style={{ color: "#D63B4D" }}>{error}</Text>
            <Pressable onPress={load} style={{ marginTop: 10 }}>
              <Text style={{ color: "#173FD1", fontWeight: "800" }}>Try again</Text>
            </Pressable>
          </View>
        ) : (
          <>
            <View style={{ backgroundColor: "#FFFFFF", borderRadius: 17, padding: 16 }}>
              <View style={{ flexDirection: "row", alignItems: "center" }}>
                <View style={{ width: 54, height: 54, borderRadius: 27, backgroundColor: "#EAF1FF", alignItems: "center", justifyContent: "center" }}>
                  <Ionicons name="person" size={25} color="#173FD1" />
                </View>
                <View style={{ flex: 1, marginLeft: 12 }}>
                  <Text style={{ fontSize: 16, fontWeight: "900", color: "#172033" }}>{patientName}</Text>
                  <Text style={{ fontSize: 11, color: "#697386", marginTop: 3 }}>
                    {booking?.age ? `Age ${booking.age}` : booking?.patient?.age ? `Age ${booking.patient.age}` : "Home-Based Care"}
                  </Text>
                </View>
                <View style={{ backgroundColor: "#EAF1FF", paddingHorizontal: 9, paddingVertical: 6, borderRadius: 9 }}>
                  <Text style={{ color: "#173FD1", fontWeight: "900", fontSize: 10 }}>{status || "OFFERED"}</Text>
                </View>
              </View>

              <Detail icon="medkit-outline" title="Service" value={booking?.serviceName || booking?.serviceType || booking?.serviceCode || booking?.careType || "-"} />
              <Detail icon="calendar-outline" title="Date & Time" value={`${booking?.startDate || booking?.appointmentDate || booking?.date || "-"} ${booking?.startTime || booking?.time || ""}`} />
              <Detail icon="location-outline" title="Patient Location" value={booking?.serviceAddress || booking?.address || booking?.patientAddress || "-"} />
              <Detail icon="cash-outline" title="Service Amount" value={booking?.amount != null ? `₹${booking.amount}` : booking?.price != null ? `₹${booking.price}` : "-"} />

              <View style={{ marginTop: 15, padding: 13, borderRadius: 12, backgroundColor: "#F7F9FD" }}>
                <Text style={{ color: "#172033", fontWeight: "900", fontSize: 11 }}>Patient Notes</Text>
                <Text style={{ color: "#697386", fontSize: 11, marginTop: 5, lineHeight: 17 }}>
                  {booking?.patientNotes || booking?.careNotes || booking?.notes || "No notes"}
                </Text>
              </View>
            </View>

            {["OFFERED", "NEW"].includes(status) ? (
              <View style={{ marginTop: 14 }}>
                <Button title={busy ? "Please wait..." : "Accept Booking"} onPress={accept} />
              </View>
            ) : null}

            {status === "ACCEPTED" ? (
              <View style={{ marginTop: 14, backgroundColor: "#FFFFFF", borderRadius: 16, padding: 16 }}>
                <Text style={{ color: "#172033", fontSize: 16, fontWeight: "900" }}>Review your booking</Text>
                <Text style={{ color: "#697386", fontSize: 12, lineHeight: 18, marginTop: 6 }}>
                  Confirm to proceed with this service, or cancel it before travelling to the patient.
                </Text>
                <Pressable disabled={busy} onPress={confirm} style={{ marginTop: 15, height: 48, borderRadius: 12, backgroundColor: busy ? "#9AA9E8" : "#173FD1", alignItems: "center", justifyContent: "center" }}>
                  <Text style={{ color: "#FFFFFF", fontWeight: "900" }}>{busy ? "Please wait..." : "Confirm Booking"}</Text>
                </Pressable>
                <Pressable disabled={busy} onPress={cancel} style={{ marginTop: 11, height: 45, borderRadius: 11, borderWidth: 1, borderColor: "#E83D52", alignItems: "center", justifyContent: "center" }}>
                  <Text style={{ color: "#E83D52", fontWeight: "900" }}>Cancel Booking</Text>
                </Pressable>
              </View>
            ) : null}

            {status === "CONFIRMED" && !reachedPatient ? (
              <View style={{ marginTop: 14, backgroundColor: "#FFFFFF", borderRadius: 16, padding: 16 }}>
                <Text style={{ color: "#172033", fontSize: 16, fontWeight: "900" }}>Booking confirmed</Text>
                <Text style={{ color: "#697386", fontSize: 12, lineHeight: 18, marginTop: 6 }}>
                  Travel to the patient. Once you arrive, mark that you have reached the location to enter the service OTP.
                </Text>
                <Pressable onPress={openMap} style={{ marginTop: 14, height: 48, borderRadius: 12, backgroundColor: "#173FD1", alignItems: "center", justifyContent: "center", flexDirection: "row" }}>
                  <Ionicons name="navigate-outline" size={19} color="#FFFFFF" />
                  <Text style={{ color: "#FFFFFF", fontWeight: "900", marginLeft: 8 }}>Go to Patient Location</Text>
                </Pressable>
                <Pressable disabled={busy} onPress={cancel} style={{ marginTop: 11, alignItems: "center", padding: 8 }}>
                  <Text style={{ color: "#E83D52", fontWeight: "800" }}>Cancel Confirmed Booking</Text>
                </Pressable>
              </View>
            ) : null}

            {status === "CONFIRMED" && reachedPatient ? (
              <View style={{ marginTop: 14, backgroundColor: "#FFFFFF", borderRadius: 16, padding: 16 }}>
                <View style={{ flexDirection: "row", alignItems: "center", backgroundColor: "#E8FAF1", padding: 11, borderRadius: 11 }}>
                  <Ionicons name="checkmark-circle" size={18} color="#16A765" />
                  <Text style={{ color: "#147A4C", fontWeight: "900", marginLeft: 7 }}>You have reached the patient</Text>
                </View>
                <Text style={{ color: "#172033", fontWeight: "900", marginTop: 16 }}>Enter Service OTP</Text>
                <Text style={{ color: "#697386", fontSize: 11, marginTop: 4 }}>Ask the patient for the OTP to start the visit.</Text>
                <TextInput value={otp} onChangeText={setOtp} maxLength={8} keyboardType="number-pad" placeholder="Enter OTP" style={{ marginTop: 13, borderWidth: 1, borderColor: "#DCE2EC", borderRadius: 11, padding: 14, textAlign: "center", fontSize: 22, fontWeight: "900", letterSpacing: 8 }} />
                <Pressable disabled={busy} onPress={start} style={{ marginTop: 11, height: 45, borderRadius: 11, backgroundColor: busy ? "#9AA9E8" : "#173FD1", alignItems: "center", justifyContent: "center" }}>
                  <Text style={{ color: "#FFFFFF", fontWeight: "900" }}>{busy ? "Please wait..." : "Start Service"}</Text>
                </Pressable>
              </View>
            ) : null}

            {status === "IN_PROGRESS" ? (
              <View style={{ marginTop: 14, backgroundColor: "#FFFFFF", borderRadius: 16, padding: 16 }}>
                <View style={{ flexDirection: "row", alignItems: "center", backgroundColor: "#E8FAF1", padding: 11, borderRadius: 11 }}>
                  <Ionicons name="radio-button-on" size={18} color="#16A765" />
                  <Text style={{ color: "#147A4C", fontWeight: "900", marginLeft: 7 }}>Service in Progress</Text>
                </View>
                <Text style={{ color: "#172033", fontWeight: "900", marginTop: 16 }}>Visit Notes</Text>
                <TextInput value={notes} onChangeText={setNotes} multiline placeholder="Add notes about the visit..." style={{ marginTop: 8, minHeight: 95, borderWidth: 1, borderColor: "#DCE2EC", borderRadius: 11, padding: 12, textAlignVertical: "top" }} />
                <Pressable disabled={busy} onPress={complete} style={{ marginTop: 12, height: 48, borderRadius: 12, backgroundColor: busy ? "#9AA9E8" : "#E83D52", alignItems: "center", justifyContent: "center" }}>
                  <Text style={{ color: "#FFFFFF", fontWeight: "900" }}>{busy ? "Please wait..." : "Complete Service"}</Text>
                </Pressable>
              </View>
            ) : null}

            {status === "COMPLETED" ? (
              <View style={{ marginTop: 14, backgroundColor: "#FFFFFF", borderRadius: 16, padding: 20, alignItems: "center" }}>
                <View style={{ width: 65, height: 65, borderRadius: 33, backgroundColor: "#E8FAF1", alignItems: "center", justifyContent: "center" }}>
                  <Ionicons name="checkmark" size={35} color="#16A765" />
                </View>
                <Text style={{ fontSize: 19, fontWeight: "900", color: "#172033", marginTop: 13 }}>Service Completed!</Text>
              </View>
            ) : null}
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}
