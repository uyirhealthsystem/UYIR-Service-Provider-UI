import { ScrollView, Text, View, Pressable, Alert } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useAuth } from "../../../../../auth/store";

export default function ProfileScreen() {
  const { user, logout } = useAuth();
  const name = (user as any)?.name || (user as any)?.fullName || "Doctor";
  const rows = [
    ["person-outline", "Personal information", "Provider profile API not supplied"],
    ["school-outline", "Qualification & experience", "Provider profile API not supplied"],
    ["cash-outline", "Consultation fees", "Provider profile API not supplied"],
    ["calendar-outline", "Availability schedule", "Manage in My schedule"],
    ["document-text-outline", "Documents & certificates", "Provider profile API not supplied"],
    ["notifications-outline", "Notifications", "Notifications endpoints are marked planned"],
  ] as const;
  return <SafeAreaView style={{ flex: 1, backgroundColor: "#F7F9FC" }} edges={["top"]}><ScrollView contentContainerStyle={{ padding: 20 }}>
    <Text style={{ color: "#15233B", fontSize: 27, fontWeight: "800" }}>Profile</Text>
    <View style={{ alignItems: "center", backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#E8EDF5", borderRadius: 20, padding: 24, marginTop: 18 }}>
      <View style={{ width: 76, height: 76, borderRadius: 26, backgroundColor: "#EAF2FF", alignItems: "center", justifyContent: "center" }}><Ionicons name="person" size={34} color="#1264E8" /></View>
      <Text style={{ color: "#15233B", fontSize: 19, fontWeight: "800", marginTop: 13 }}>{name}</Text>
      <Text style={{ color: "#778399", marginTop: 4 }}>{user?.providerType || user?.role || "Teleconsultation provider"}</Text>
    </View>
    <View style={{ backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#E8EDF5", borderRadius: 18, paddingHorizontal: 15, marginTop: 16 }}>
      {rows.map(([icon, title, subtitle], i) => <View key={title} style={{ flexDirection: "row", alignItems: "center", paddingVertical: 15, borderBottomWidth: i === rows.length - 1 ? 0 : 1, borderBottomColor: "#F0F2F6" }}><Ionicons name={icon as any} size={21} color="#1264E8" /><View style={{ flex: 1, marginLeft: 12 }}><Text style={{ color: "#15233B", fontWeight: "700" }}>{title}</Text><Text style={{ color: "#8994A5", fontSize: 11, marginTop: 4 }}>{subtitle}</Text></View><Ionicons name="chevron-forward" size={17} color="#A0AABB" /></View>)}
    </View>
    <Pressable onPress={() => Alert.alert("Log out?", "Are you sure you want to log out?", [{ text: "Cancel", style: "cancel" }, { text: "Log out", style: "destructive", onPress: logout }])} style={{ marginTop: 20, padding: 16, borderRadius: 14, backgroundColor: "#FFF0F0", alignItems: "center" }}><Text style={{ color: "#C53030", fontWeight: "800" }}>Log out</Text></Pressable>
  </ScrollView></SafeAreaView>;
}
