import { useState } from "react";
import { Alert, Pressable, ScrollView, Text, View, ActivityIndicator } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { createOrGetSession, startConsultation, endConsultation, markDoctorDelayed } from "../../../api/appointments";

const BLUE = "#1264E8";
export default function AppointmentDetailsScreen({ route, navigation }: any) {
  const appointmentId = String(route?.params?.appointmentId || "");
  const [busy, setBusy] = useState("");
  const run = async (key: string, action: () => Promise<any>, success: string, next?: string) => {
    try {
      setBusy(key);
      const result = await action();
      Alert.alert(success, "The server accepted the request.");
      if (next) navigation.navigate(next, { appointmentId, session: result });
    } catch (error: any) {
      Alert.alert("Unable to complete", error?.message || "Please try again.");
    } finally { setBusy(""); }
  };
  const action = (label: string, icon: any, key: string, fn: () => void, primary = false) => (
    <Pressable onPress={fn} disabled={!!busy} style={{ flexDirection: "row", alignItems: "center", padding: 16, borderRadius: 14, backgroundColor: primary ? BLUE : "#FFFFFF", borderWidth: primary ? 0 : 1, borderColor: "#E6EBF3", marginTop: 10 }}>
      {busy === key ? <ActivityIndicator color={primary ? "#fff" : BLUE} /> : <Ionicons name={icon} size={21} color={primary ? "#fff" : BLUE} />}
      <Text style={{ color: primary ? "#FFFFFF" : "#15233B", fontWeight: "700", marginLeft: 12, flex: 1 }}>{label}</Text>
      <Ionicons name="chevron-forward" size={18} color={primary ? "#fff" : "#8A96A8"} />
    </Pressable>
  );
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#F7F9FC" }} edges={["top"]}>
      <ScrollView contentContainerStyle={{ padding: 20 }}>
        <Pressable onPress={() => navigation.goBack()} style={{ flexDirection: "row", alignItems: "center", marginBottom: 20 }}><Ionicons name="arrow-back" size={22} color="#15233B" /><Text style={{ color: "#15233B", marginLeft: 8 }}>Back</Text></Pressable>
        <Text style={{ color: "#15233B", fontSize: 26, fontWeight: "800" }}>Appointment details</Text>
        <Text style={{ color: "#778399", marginTop: 8 }}>ID: {appointmentId}</Text>
        <View style={{ backgroundColor: "#EAF2FF", borderRadius: 18, padding: 16, marginTop: 22, flexDirection: "row", gap: 12 }}>
          <Ionicons name="shield-checkmark-outline" size={25} color={BLUE} />
          <View style={{ flex: 1 }}><Text style={{ color: "#15233B", fontWeight: "800" }}>Patient privacy first</Text><Text style={{ color: "#65738A", lineHeight: 19, marginTop: 4 }}>Confirm the appointment and patient details before starting a session.</Text></View>
        </View>
        {action("Create or retrieve session", "videocam-outline", "session", () => run("session", () => createOrGetSession(appointmentId), "Session ready", "TCConsultationRoom"), true)}
        {action("Start consultation", "play-circle-outline", "start", () => run("start", () => startConsultation(appointmentId), "Consultation started", "TCConsultationRoom"))}
        {action("Mark doctor delayed", "time-outline", "delay", () => run("delay", () => markDoctorDelayed(appointmentId), "Delay recorded"))}
        {action("Consultation notes", "document-text-outline", "notes", () => navigation.navigate("TCConsultationNotes", { appointmentId }))}
        {action("Prescription", "medkit-outline", "prescription", () => navigation.navigate("TCPrescriptions", { appointmentId }))}
        {action("End consultation", "checkmark-circle-outline", "end", () => run("end", () => endConsultation(appointmentId), "Consultation ended"))}
        {busy ? <ActivityIndicator style={{ marginTop: 15 }} color={BLUE} /> : null}
      </ScrollView>
    </SafeAreaView>
  );
}
