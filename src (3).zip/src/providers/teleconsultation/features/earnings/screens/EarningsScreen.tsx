import { ScrollView, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";

export default function EarningsScreen() {
  return <SafeAreaView style={{ flex: 1, backgroundColor: "#F7F9FC" }} edges={["top"]}><ScrollView contentContainerStyle={{ padding: 20 }}>
    <Text style={{ color: "#15233B", fontSize: 27, fontWeight: "800" }}>Earnings</Text><Text style={{ color: "#778399", marginTop: 6 }}>Your consultation payment overview</Text>
    <View style={{ marginTop: 22, borderRadius: 22, backgroundColor: "#1055BD", padding: 22 }}>
      <Text style={{ color: "#D7E7FF", fontSize: 13 }}>Total earnings</Text><Text style={{ color: "#FFFFFF", fontSize: 34, fontWeight: "800", marginTop: 8 }}>—</Text><Text style={{ color: "#D7E7FF", fontSize: 12, marginTop: 8 }}>Earnings summary API is not included in the supplied collection.</Text>
    </View>
    <View style={{ marginTop: 16, backgroundColor: "#FFFFFF", borderRadius: 18, borderWidth: 1, borderColor: "#E8EDF5", padding: 18, flexDirection: "row", alignItems: "center" }}><Ionicons name="information-circle-outline" size={24} color="#1264E8" /><Text style={{ flex: 1, marginLeft: 10, color: "#778399", lineHeight: 20 }}>No amounts or payout history are fabricated. Connect the earnings endpoint when the backend team provides it.</Text></View>
  </ScrollView></SafeAreaView>;
}
