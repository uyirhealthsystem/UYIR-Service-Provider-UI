import { useCallback, useEffect, useState } from "react";
import { ActivityIndicator, RefreshControl, ScrollView, Text, Pressable, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useAuth } from "../../../../../auth/store";
import { getDoctorAppointments, getPendingDoctorAppointments } from "../../../api/appointments";
import { getLocalDateString } from "../../../api/date";

const BLUE = "#0866E8";
const NAVY = "#14233D";
const MUTED = "#8490A3";
const LINE = "#E9EEF5";
const WHITE = "#FFFFFF";

function unwrap(value: any): any[] {
  if (Array.isArray(value)) return value;
  if (Array.isArray(value?.data)) return value.data;
  if (Array.isArray(value?.appointments)) return value.appointments;
  if (Array.isArray(value?.data?.appointments)) return value.data.appointments;
  if (Array.isArray(value?.items)) return value.items;
  return [];
}

function getPatientName(item: any) {
  return item?.patient?.fullName || item?.patient?.name || item?.patientName || item?.patient?.firstName || "Patient";
}
function getTime(item: any) {
  const value = item?.scheduledAt || item?.appointmentDateTime || item?.dateTime;
  if (!value) return "Time not provided";
  return new Date(value).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

export default function TeleconsultationDashboard({ navigation }: any) {
  const { user } = useAuth();
  const [appointments, setAppointments] = useState<any[]>([]);
  const [pending, setPending] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const name = String((user as any)?.name || (user as any)?.fullName || "Doctor").replace(/^Dr\.\s*/i, "");

  const load = useCallback(async () => {
    const date = getLocalDateString();
    const results = await Promise.allSettled([getDoctorAppointments(date), getPendingDoctorAppointments(date)]);
    if (results[0].status === "fulfilled") setAppointments(unwrap(results[0].value));
    if (results[1].status === "fulfilled") setPending(unwrap(results[1].value));
  }, []);

  useEffect(() => {
    load().finally(() => setLoading(false));
  }, [load]);

  const refresh = async () => {
    setRefreshing(true);
    try { await load(); } finally { setRefreshing(false); }
  };

  const next = appointments
    .filter((item) => !["COMPLETED", "CANCELLED", "REJECTED"].includes(String(item?.status || "").toUpperCase()))
    .sort((a, b) => new Date(a?.scheduledAt || 0).getTime() - new Date(b?.scheduledAt || 0).getTime())[0];

  const countCompleted = appointments.filter((item) => String(item?.status || "").toUpperCase() === "COMPLETED").length;

  const shortcuts = [
    { label: "Appointments", detail: "View patient bookings", icon: "calendar-outline" as const, tint: "#EAF2FF", screen: "Appointments" },
    { label: "My Schedule", detail: "Manage available hours", icon: "time-outline" as const, tint: "#EAF8F1", screen: "Schedule" },
    { label: "Prescriptions", detail: "Clinical prescriptions", icon: "document-text-outline" as const, tint: "#F2EEFF", screen: "Appointments" },
    { label: "Earnings", detail: "Payment overview", icon: "wallet-outline" as const, tint: "#FFF4E6", screen: "Earnings" },
  ];

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#F5F7FB" }} edges={["top"]}>
      <ScrollView showsVerticalScrollIndicator={false} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refresh} tintColor={BLUE} />} contentContainerStyle={{ paddingHorizontal: 18, paddingTop: 10, paddingBottom: 24 }}>
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
          <View>
            <Text style={{ color: BLUE, fontSize: 12, fontWeight: "800", letterSpacing: 1.2 }}>UYIR  /  TELECONSULTATION</Text>
            <Text style={{ color: NAVY, fontSize: 25, fontWeight: "800", marginTop: 8 }}>Good morning,</Text>
            <Text style={{ color: NAVY, fontSize: 21, fontWeight: "800", marginTop: 1 }}>Dr. {name}</Text>
            <View style={{ flexDirection: "row", alignItems: "center", marginTop: 7 }}>
              <View style={{ width: 7, height: 7, borderRadius: 5, backgroundColor: "#19B36B", marginRight: 6 }} />
              <Text style={{ color: "#168653", fontSize: 12, fontWeight: "700" }}>Provider account</Text>
            </View>
          </View>
          <Pressable onPress={() => navigation.navigate("Profile")} style={{ width: 46, height: 46, borderRadius: 16, backgroundColor: WHITE, borderWidth: 1, borderColor: LINE, alignItems: "center", justifyContent: "center" }}>
            <Ionicons name="notifications-outline" size={21} color={NAVY} />
          </Pressable>
        </View>

        <View style={{ backgroundColor: WHITE, borderRadius: 20, padding: 17, borderWidth: 1, borderColor: LINE }}>
          <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
            <View><Text style={{ color: NAVY, fontSize: 16, fontWeight: "800" }}>Today at a glance</Text><Text style={{ color: MUTED, fontSize: 12, marginTop: 3 }}>Your consultation overview</Text></View>
            <View style={{ width: 40, height: 40, borderRadius: 13, backgroundColor: "#EAF2FF", alignItems: "center", justifyContent: "center" }}><Ionicons name="videocam-outline" size={21} color={BLUE} /></View>
          </View>
          <View style={{ flexDirection: "row", marginTop: 18 }}>
            {[{ label: "Today", value: String(appointments.length) }, { label: "Pending", value: String(pending.length) }, { label: "Completed", value: String(countCompleted) }].map((item, index) => (
              <View key={item.label} style={{ flex: 1, alignItems: "center", borderRightWidth: index < 2 ? 1 : 0, borderRightColor: LINE }}>
                <Text style={{ color: index === 1 ? "#15945C" : BLUE, fontSize: 27, fontWeight: "800" }}>{loading ? "—" : item.value}</Text>
                <Text style={{ color: MUTED, fontSize: 11, marginTop: 4 }}>{item.label}</Text>
              </View>
            ))}
          </View>
        </View>

        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 24, marginBottom: 11 }}>
          <Text style={{ color: NAVY, fontSize: 18, fontWeight: "800" }}>Next consultation</Text>
          <Pressable onPress={() => navigation.navigate("Appointments")}><Text style={{ color: BLUE, fontSize: 12, fontWeight: "800" }}>See all</Text></Pressable>
        </View>
        <View style={{ backgroundColor: WHITE, borderRadius: 19, padding: 15, borderWidth: 1, borderColor: LINE }}>
          {loading ? <ActivityIndicator color={BLUE} /> : next ? (
            <Pressable onPress={() => navigation.navigate("TCAppointmentDetails", { appointmentId: String(next.id || next.appointmentId) })} style={{ flexDirection: "row", alignItems: "center" }}>
              <View style={{ width: 45, height: 45, borderRadius: 15, backgroundColor: "#EAF2FF", alignItems: "center", justifyContent: "center" }}><Ionicons name="person-outline" size={22} color={BLUE} /></View>
              <View style={{ flex: 1, marginLeft: 11 }}>
                <Text style={{ color: NAVY, fontSize: 14, fontWeight: "800" }}>{getPatientName(next)}</Text>
                <Text style={{ color: MUTED, fontSize: 11, marginTop: 4 }}>{getTime(next)}  ·  {next?.reason || next?.consultationType || "Video consultation"}</Text>
              </View>
              <View style={{ backgroundColor: BLUE, borderRadius: 10, paddingHorizontal: 14, paddingVertical: 9 }}><Text style={{ color: WHITE, fontSize: 12, fontWeight: "800" }}>Open</Text></View>
            </Pressable>
          ) : (
            <View style={{ alignItems: "center", paddingVertical: 13 }}>
              <Ionicons name="calendar-clear-outline" size={27} color="#AAB5C5" />
              <Text style={{ color: NAVY, fontWeight: "700", marginTop: 8 }}>No upcoming consultation found</Text>
              <Text style={{ color: MUTED, fontSize: 11, marginTop: 4 }}>Your appointments will appear here.</Text>
            </View>
          )}
        </View>

        <Text style={{ color: NAVY, fontSize: 18, fontWeight: "800", marginTop: 24, marginBottom: 12 }}>Quick access</Text>
        <View style={{ flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between" }}>
          {shortcuts.map((item) => (
            <Pressable key={item.label} onPress={() => navigation.navigate(item.screen)} style={{ width: "48.3%", minHeight: 112, backgroundColor: WHITE, borderRadius: 17, borderWidth: 1, borderColor: LINE, padding: 14, marginBottom: 11 }}>
              <View style={{ width: 39, height: 39, borderRadius: 12, backgroundColor: item.tint, alignItems: "center", justifyContent: "center" }}><Ionicons name={item.icon} size={20} color={BLUE} /></View>
              <Text style={{ color: NAVY, fontSize: 13, fontWeight: "800", marginTop: 11 }}>{item.label}</Text>
              <Text style={{ color: MUTED, fontSize: 10, marginTop: 3 }}>{item.detail}</Text>
            </Pressable>
          ))}
        </View>
        <Pressable onPress={() => navigation.navigate("Profile")} style={{ flexDirection: "row", alignItems: "center", padding: 15, borderRadius: 16, backgroundColor: "#EAF2FF", marginTop: 5 }}>
          <Ionicons name="person-circle-outline" size={25} color={BLUE} />
          <Text style={{ color: NAVY, fontSize: 13, fontWeight: "800", flex: 1, marginLeft: 9 }}>Professional profile</Text>
          <Ionicons name="chevron-forward" size={18} color={BLUE} />
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}
