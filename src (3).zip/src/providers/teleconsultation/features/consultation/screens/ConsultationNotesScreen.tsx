import { useState } from "react";
import { Alert, Pressable, ScrollView, Text, TextInput, View, ActivityIndicator } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { createNoteDraft, finalizeNote } from "../../../api/notes";

const BLUE = "#1264E8";
export default function ConsultationNotesScreen({ route }: any) {
  const appointmentId = String(route?.params?.appointmentId || "");
  const [symptoms, setSymptoms] = useState("");
  const [diagnosis, setDiagnosis] = useState("");
  const [clinicalNotes, setClinicalNotes] = useState("");
  const [advice, setAdvice] = useState("");
  const [noteId, setNoteId] = useState("");
  const [busy, setBusy] = useState(false);
  const field = (label: string, value: string, setter: (v: string) => void, placeholder: string) => (
    <View style={{ marginTop: 16 }}><Text style={{ color: "#26354C", fontWeight: "700", marginBottom: 8 }}>{label}</Text><TextInput value={value} onChangeText={setter} placeholder={placeholder} multiline style={{ minHeight: 82, textAlignVertical: "top", backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#E2E8F0", borderRadius: 13, padding: 13, color: "#15233B" }} /></View>
  );
  const save = async () => {
    if (!appointmentId) { Alert.alert("Missing appointment", "Open notes from an appointment."); return; }
    try {
      setBusy(true);
      const result: any = await createNoteDraft(appointmentId, { symptoms, diagnosis, clinicalNotes, advice });
      const id = result?.id || result?.data?.id || result?.note?.id || "";
      if (id) setNoteId(String(id));
      Alert.alert("Draft saved", "The note was sent to the server.");
    } catch (e: any) { Alert.alert("Could not save note", e?.message || "Please try again."); }
    finally { setBusy(false); }
  };
  const finalize = async () => {
    if (!noteId) { Alert.alert("Save draft first", "The API response must return a note ID before finalizing."); return; }
    try { setBusy(true); await finalizeNote(appointmentId, noteId); Alert.alert("Finalized", "The consultation note was finalized."); }
    catch (e: any) { Alert.alert("Could not finalize", e?.message || "Please try again."); }
    finally { setBusy(false); }
  };
  return <SafeAreaView style={{ flex: 1, backgroundColor: "#F7F9FC" }} edges={["top"]}>
    <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 32 }}>
      <Text style={{ color: "#15233B", fontSize: 26, fontWeight: "800" }}>Consultation notes</Text>
      <Text style={{ color: "#778399", marginTop: 6 }}>Appointment {appointmentId}</Text>
      {field("Symptoms", symptoms, setSymptoms, "Patient-reported symptoms")}
      {field("Diagnosis", diagnosis, setDiagnosis, "Clinical diagnosis")}
      {field("Clinical notes", clinicalNotes, setClinicalNotes, "Examination and relevant findings")}
      {field("Advice & follow-up", advice, setAdvice, "Advice discussed with the patient")}
      <Pressable disabled={busy} onPress={save} style={{ marginTop: 22, padding: 16, backgroundColor: BLUE, borderRadius: 14, alignItems: "center" }}>{busy ? <ActivityIndicator color="#fff" /> : <Text style={{ color: "#fff", fontWeight: "800" }}>Save draft</Text>}</Pressable>
      <Pressable disabled={busy} onPress={finalize} style={{ marginTop: 10, padding: 16, backgroundColor: "#FFFFFF", borderRadius: 14, borderWidth: 1, borderColor: "#DCE5F2", alignItems: "center" }}><Text style={{ color: BLUE, fontWeight: "800" }}>Finalize note</Text></Pressable>
    </ScrollView>
  </SafeAreaView>;
}
