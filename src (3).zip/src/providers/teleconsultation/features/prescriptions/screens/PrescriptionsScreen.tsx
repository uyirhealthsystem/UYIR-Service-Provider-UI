import { useState } from "react";
import { Alert, Pressable, ScrollView, Text, TextInput, View, ActivityIndicator } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { createPrescriptionDraft, updatePrescriptionInstructions, addMedicine, issuePrescription } from "../../../api/prescriptions";

const BLUE = "#1264E8";
export default function PrescriptionsScreen({ route }: any) {
  const appointmentId = String(route?.params?.appointmentId || "");
  const [instructions, setInstructions] = useState("");
  const [medicineName, setMedicineName] = useState("");
  const [dosage, setDosage] = useState("");
  const [frequency, setFrequency] = useState("");
  const [duration, setDuration] = useState("");
  const [quantity, setQuantity] = useState("1");
  const [busy, setBusy] = useState(false);
  const call = async (fn: () => Promise<any>, message: string) => {
    if (!appointmentId) { Alert.alert("Appointment required", "Open prescriptions from a specific appointment."); return; }
    try { setBusy(true); await fn(); Alert.alert(message, "The server accepted the request."); }
    catch (e: any) { Alert.alert("Request failed", e?.message || "Please try again."); }
    finally { setBusy(false); }
  };
  const field = (label: string, value: string, set: (v: string) => void) => <View style={{ marginTop: 13 }}><Text style={{ color: "#26354C", fontWeight: "700", marginBottom: 7 }}>{label}</Text><TextInput value={value} onChangeText={set} style={{ backgroundColor: "#fff", borderWidth: 1, borderColor: "#E2E8F0", borderRadius: 12, padding: 13, color: "#15233B" }} /></View>;
  const button = (title: string, fn: () => void, primary = false) => <Pressable disabled={busy} onPress={fn} style={{ marginTop: 11, backgroundColor: primary ? BLUE : "#fff", borderRadius: 13, borderWidth: primary ? 0 : 1, borderColor: "#E2E8F0", padding: 15, alignItems: "center" }}><Text style={{ color: primary ? "#fff" : BLUE, fontWeight: "800" }}>{title}</Text></Pressable>;
  return <SafeAreaView style={{ flex: 1, backgroundColor: "#F7F9FC" }} edges={["top"]}><ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 32 }}>
    <Text style={{ color: "#15233B", fontSize: 27, fontWeight: "800" }}>Prescription</Text><Text style={{ color: "#778399", marginTop: 6 }}>Appointment {appointmentId || "not selected"}</Text>
    {field("Instructions", instructions, setInstructions)}
    {button("Create draft", () => call(() => createPrescriptionDraft(appointmentId, instructions), "Prescription draft created"), true)}
    {button("Update instructions", () => call(() => updatePrescriptionInstructions(appointmentId, instructions), "Instructions updated"))}
    <Text style={{ color: "#15233B", fontSize: 18, fontWeight: "800", marginTop: 26 }}>Add medicine</Text>
    {field("Medicine name", medicineName, setMedicineName)}
    {field("Dosage", dosage, setDosage)}
    {field("Frequency", frequency, setFrequency)}
    {field("Duration", duration, setDuration)}
    {field("Quantity", quantity, setQuantity)}
    {button("Add medicine", () => call(() => addMedicine(appointmentId, { medicineName, dosage, frequency, duration, quantity: Number(quantity), sortOrder: 0 }), "Medicine added"))}
    {button("Issue prescription", () => call(() => issuePrescription(appointmentId), "Prescription issued"))}
    {busy ? <ActivityIndicator style={{ marginTop: 14 }} color={BLUE} /> : null}
    <Text style={{ color: "#778399", fontSize: 12, lineHeight: 18, marginTop: 14 }}>Enter only the clinician-approved prescription details. This screen sends the values you enter; it does not recommend medicines.</Text>
  </ScrollView></SafeAreaView>;
}
