import React, { type ReactNode } from "react";
import {
  ActivityIndicator, Pressable, RefreshControl, ScrollView, StyleSheet, Text, TextInput, View,
  type StyleProp, type TextInputProps, type ViewStyle,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { SafeAreaView, useSafeAreaInsets } from "react-native-safe-area-context";

export const C = {
  primary: "#0B63CE", primaryDark: "#0A4FA3", primarySoft: "#E8F1FC",
  ink: "#14233B", muted: "#66758B", line: "#E2E8F0", bg: "#F4F7FB", card: "#FFFFFF",
  success: "#0E9F6E", successSoft: "#E3F6EE", warn: "#B96A00", warnSoft: "#FFF3DC",
  danger: "#D1304A", dangerSoft: "#FDE8EC", gray: "#8795A8", graySoft: "#EEF1F5",
};

type Tone = "primary" | "success" | "warn" | "danger" | "gray";
const toneMap: Record<Tone, { fg: string; bg: string }> = {
  primary: { fg: C.primary, bg: C.primarySoft },
  success: { fg: C.success, bg: C.successSoft },
  warn: { fg: C.warn, bg: C.warnSoft },
  danger: { fg: C.danger, bg: C.dangerSoft },
  gray: { fg: C.muted, bg: C.graySoft },
};

/* ───────── Screen shell ───────── */
export function Screen({
  title, subtitle, onBack, right, children, onRefresh, refreshing = false, scroll = true, footer,
}: {
  title: string; subtitle?: string; onBack?: () => void; right?: ReactNode; children: ReactNode;
  onRefresh?: () => void; refreshing?: boolean; scroll?: boolean; footer?: ReactNode;
}) {
  const insets = useSafeAreaInsets();
  return (
    <SafeAreaView edges={["top"]} style={s.screen}>
      <View style={s.header}>
        {onBack ? (
          <Pressable onPress={onBack} hitSlop={10} style={s.backBtn} accessibilityLabel="Go back">
            <Ionicons name="chevron-back" size={22} color={C.ink} />
          </Pressable>
        ) : null}
        <View style={{ flex: 1 }}>
          <Text style={s.title} numberOfLines={1}>{title}</Text>
          {subtitle ? <Text style={s.subtitle} numberOfLines={1}>{subtitle}</Text> : null}
        </View>
        {right}
      </View>
      {scroll ? (
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{ padding: 16, paddingBottom: (footer ? 16 : insets.bottom + 24) }}
          keyboardShouldPersistTaps="handled"
          refreshControl={onRefresh ? <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={C.primary} /> : undefined}
        >
          {children}
        </ScrollView>
      ) : (
        <View style={{ flex: 1, padding: 16 }}>{children}</View>
      )}
      {footer ? <View style={[s.footer, { paddingBottom: insets.bottom + 12 }]}>{footer}</View> : null}
    </SafeAreaView>
  );
}

/* ───────── Primitives ───────── */
export function Card({ children, style, onPress }: { children: ReactNode; style?: StyleProp<ViewStyle>; onPress?: () => void }) {
  const Comp: any = onPress ? Pressable : View;
  return <Comp onPress={onPress} style={[s.card, style]}>{children}</Comp>;
}

export function SectionTitle({ title, right }: { title: string; right?: ReactNode }) {
  return (
    <View style={s.sectionRow}>
      <Text style={s.sectionTitle}>{title}</Text>
      {right}
    </View>
  );
}

export function Button({
  title, onPress, variant = "primary", loading, disabled, icon, small, style,
}: {
  title: string; onPress: () => void; variant?: "primary" | "secondary" | "danger" | "success" | "ghost" | "dangerOutline";
  loading?: boolean; disabled?: boolean; icon?: keyof typeof Ionicons.glyphMap; small?: boolean; style?: StyleProp<ViewStyle>;
}) {
  const v = {
    primary: { bg: C.primary, fg: "#fff", border: C.primary },
    success: { bg: C.success, fg: "#fff", border: C.success },
    danger: { bg: C.danger, fg: "#fff", border: C.danger },
    secondary: { bg: C.primarySoft, fg: C.primary, border: C.primarySoft },
    ghost: { bg: "transparent", fg: C.primary, border: C.line },
    dangerOutline: { bg: "#fff", fg: C.danger, border: C.danger },
  }[variant];
  const off = disabled || loading;
  return (
    <Pressable
      onPress={onPress} disabled={off}
      style={({ pressed }) => [
        s.btn, small && s.btnSmall,
        { backgroundColor: v.bg, borderColor: v.border, opacity: off ? 0.55 : pressed ? 0.85 : 1 }, style,
      ]}
    >
      {loading ? <ActivityIndicator size="small" color={v.fg} /> : (
        <>
          {icon ? <Ionicons name={icon} size={small ? 15 : 18} color={v.fg} style={{ marginRight: 6 }} /> : null}
          <Text style={[s.btnText, small && { fontSize: 13 }, { color: v.fg }]}>{title}</Text>
        </>
      )}
    </Pressable>
  );
}

export function Pill({ text, tone = "gray" }: { text: string; tone?: Tone }) {
  const t = toneMap[tone];
  return (
    <View style={[s.pill, { backgroundColor: t.bg }]}>
      <Text style={[s.pillText, { color: t.fg }]}>{text}</Text>
    </View>
  );
}

const statusTone: Record<string, Tone> = {
  CONFIRMED: "primary", RESCHEDULED: "warn", COMPLETED: "success", NO_SHOW: "gray", CANCELLED: "danger",
  REQUESTED: "danger", ACCEPTED: "primary", REJECTED: "gray",
};
export const StatusPill = ({ status }: { status: string }) => (
  <Pill text={status.replace("_", " ")} tone={statusTone[status] || "gray"} />
);

export function ProgressBar({ value, max, color }: { value: number; max: number | null; color?: string }) {
  const pct = max && max > 0 ? Math.min(1, value / max) : 0;
  const barColor = color || (pct >= 1 ? C.danger : pct >= 0.8 ? C.warn : C.primary);
  return (
    <View style={s.track}>
      <View style={[s.fill, { width: `${Math.max(max ? 3 : 0, pct * 100)}%`, backgroundColor: barColor }]} />
    </View>
  );
}

export function Stat({ icon, value, label, tone = "primary" }: { icon: keyof typeof Ionicons.glyphMap; value: string | number; label: string; tone?: Tone }) {
  const t = toneMap[tone];
  return (
    <View style={s.stat}>
      <View style={[s.statIcon, { backgroundColor: t.bg }]}><Ionicons name={icon} size={17} color={t.fg} /></View>
      <Text style={s.statValue}>{value}</Text>
      <Text style={s.statLabel} numberOfLines={1}>{label}</Text>
    </View>
  );
}

export function Empty({ icon = "file-tray-outline", title, hint }: { icon?: keyof typeof Ionicons.glyphMap; title: string; hint?: string }) {
  return (
    <View style={s.empty}>
      <Ionicons name={icon} size={34} color={C.gray} />
      <Text style={s.emptyTitle}>{title}</Text>
      {hint ? <Text style={s.emptyHint}>{hint}</Text> : null}
    </View>
  );
}

export function Banner({ tone = "warn", text, action }: { tone?: Tone; text: string; action?: { label: string; onPress: () => void } }) {
  const t = toneMap[tone];
  return (
    <View style={[s.banner, { backgroundColor: t.bg }]}>
      <Text style={{ color: t.fg, flex: 1, fontSize: 13, lineHeight: 18, fontWeight: "600" }}>{text}</Text>
      {action ? <Pressable onPress={action.onPress} hitSlop={8}><Text style={{ color: t.fg, fontWeight: "800", fontSize: 13 }}>{action.label}</Text></Pressable> : null}
    </View>
  );
}

export const ErrorText = ({ text }: { text?: string }) => (text ? <Text style={s.error}>{text}</Text> : null);

export function Field({ label, ...rest }: TextInputProps & { label: string }) {
  return (
    <View style={{ marginBottom: 12 }}>
      <Text style={s.fieldLabel}>{label}</Text>
      <TextInput {...rest} placeholderTextColor="#9AA6B7" style={[s.input, rest.multiline && { minHeight: 76, textAlignVertical: "top" }, rest.style]} />
    </View>
  );
}

export function Chip({ label, active, onPress }: { label: string; active?: boolean; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={[s.chip, active && { backgroundColor: C.primary, borderColor: C.primary }]}>
      <Text style={[s.chipText, active && { color: "#fff" }]}>{label}</Text>
    </Pressable>
  );
}

export function Stepper({ value, onChange, min = 1, max = 1000, step = 1 }: { value: number; onChange: (n: number) => void; min?: number; max?: number; step?: number }) {
  return (
    <View style={s.stepper}>
      <Pressable onPress={() => onChange(Math.max(min, value - step))} style={s.stepBtn} hitSlop={6}><Ionicons name="remove" size={20} color={C.primary} /></Pressable>
      <Text style={s.stepValue}>{value}</Text>
      <Pressable onPress={() => onChange(Math.min(max, value + step))} style={s.stepBtn} hitSlop={6}><Ionicons name="add" size={20} color={C.primary} /></Pressable>
    </View>
  );
}

export function Avatar({ name, size = 42 }: { name: string; size?: number }) {
  const initials = name.replace(/^dr\.?\s*/i, "").split(/\s+/).slice(0, 2).map((p) => p[0]?.toUpperCase()).join("") || "D";
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: C.primarySoft, alignItems: "center", justifyContent: "center" }}>
      <Text style={{ color: C.primary, fontWeight: "800", fontSize: size * 0.36 }}>{initials}</Text>
    </View>
  );
}

export const Row = ({ label, value }: { label: string; value?: string | number | null }) => (
  <View style={s.row}>
    <Text style={s.rowLabel}>{label}</Text>
    <Text style={s.rowValue}>{value === undefined || value === null || value === "" ? "—" : String(value)}</Text>
  </View>
);

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: C.bg },
  header: { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 12, backgroundColor: C.card, borderBottomWidth: 1, borderBottomColor: C.line, gap: 8 },
  backBtn: { width: 34, height: 34, borderRadius: 17, alignItems: "center", justifyContent: "center", backgroundColor: C.bg },
  title: { fontSize: 20, fontWeight: "800", color: C.ink },
  subtitle: { fontSize: 12.5, color: C.muted, marginTop: 1 },
  footer: { paddingHorizontal: 16, paddingTop: 12, backgroundColor: C.card, borderTopWidth: 1, borderTopColor: C.line },
  card: { backgroundColor: C.card, borderRadius: 14, borderWidth: 1, borderColor: C.line, padding: 14, marginBottom: 10 },
  sectionRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 8, marginBottom: 10 },
  sectionTitle: { fontSize: 16, fontWeight: "800", color: C.ink },
  btn: { flexDirection: "row", alignItems: "center", justifyContent: "center", paddingVertical: 13, paddingHorizontal: 16, borderRadius: 12, borderWidth: 1 },
  btnSmall: { paddingVertical: 8, paddingHorizontal: 12, borderRadius: 10 },
  btnText: { fontSize: 15, fontWeight: "700" },
  pill: { alignSelf: "flex-start", paddingHorizontal: 9, paddingVertical: 3, borderRadius: 20 },
  pillText: { fontSize: 11, fontWeight: "800", letterSpacing: 0.2 },
  track: { height: 7, borderRadius: 4, backgroundColor: C.graySoft, overflow: "hidden" },
  fill: { height: 7, borderRadius: 4 },
  stat: { flex: 1, minWidth: 0, backgroundColor: C.card, borderRadius: 14, borderWidth: 1, borderColor: C.line, padding: 12 },
  statIcon: { width: 30, height: 30, borderRadius: 9, alignItems: "center", justifyContent: "center" },
  statValue: { fontSize: 22, fontWeight: "800", color: C.ink, marginTop: 8 },
  statLabel: { fontSize: 11.5, color: C.muted, marginTop: 2 },
  empty: { alignItems: "center", paddingVertical: 36, paddingHorizontal: 24 },
  emptyTitle: { marginTop: 10, fontSize: 15, fontWeight: "700", color: C.ink, textAlign: "center" },
  emptyHint: { marginTop: 4, fontSize: 13, color: C.muted, textAlign: "center", lineHeight: 18 },
  banner: { flexDirection: "row", alignItems: "center", gap: 12, padding: 12, borderRadius: 12, marginBottom: 12 },
  error: { color: C.danger, fontSize: 13, marginVertical: 6, lineHeight: 18 },
  fieldLabel: { color: C.muted, fontWeight: "600", fontSize: 13, marginBottom: 6 },
  input: { backgroundColor: "#F8FAFD", borderWidth: 1, borderColor: C.line, borderRadius: 11, paddingHorizontal: 13, paddingVertical: 11, color: C.ink, fontSize: 15 },
  chip: { paddingHorizontal: 13, paddingVertical: 8, borderRadius: 20, borderWidth: 1, borderColor: C.line, backgroundColor: C.card },
  chipText: { fontSize: 13, fontWeight: "700", color: C.muted },
  stepper: { flexDirection: "row", alignItems: "center", gap: 6 },
  stepBtn: { width: 38, height: 38, borderRadius: 10, backgroundColor: C.primarySoft, alignItems: "center", justifyContent: "center" },
  stepValue: { minWidth: 48, textAlign: "center", fontSize: 18, fontWeight: "800", color: C.ink },
  row: { flexDirection: "row", paddingVertical: 8, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: C.line },
  rowLabel: { width: 112, color: C.muted, fontSize: 13 },
  rowValue: { flex: 1, color: C.ink, fontSize: 14, fontWeight: "600" },
});
