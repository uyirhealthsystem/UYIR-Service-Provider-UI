import { createNativeStackNavigator } from "@react-navigation/native-stack";
import HospitalLayout from "./layout";
import HospitalDoctorForm from "./features/doctors/screens/HospitalDoctorForm";
import HospitalSlots from "./features/slots/screens/HospitalSlots";
import HospitalAssign from "./features/assignments/screens/HospitalAssign";
import HospitalSchedule from "./features/schedules/screens/HospitalSchedule";
import HospitalDoctorPatients from "./features/appointments/screens/HospitalDoctorPatients";
import HospitalAppointmentDetail from "./features/appointments/screens/HospitalAppointmentDetail";
import HospitalMarkComplete from "./features/appointments/screens/HospitalMarkComplete";
import EmergencyAlertModal from "./components/EmergencyAlertModal";
import { HospitalProvider } from "./features/provider-state/store";

const Stack = createNativeStackNavigator();

export default function HospitalRoutes() {
  return (
    <HospitalProvider>
      <Stack.Navigator screenOptions={{ headerShown: false }} initialRouteName="HospitalTabs">
        <Stack.Screen name="HospitalTabs" component={HospitalLayout} />
        <Stack.Screen name="HospitalDoctorForm" component={HospitalDoctorForm} />
        <Stack.Screen name="HospitalSlots" component={HospitalSlots} />
        <Stack.Screen name="HospitalAssign" component={HospitalAssign} />
        <Stack.Screen name="HospitalSchedule" component={HospitalSchedule} />
        <Stack.Screen name="HospitalDoctorPatients" component={HospitalDoctorPatients} />
        <Stack.Screen name="HospitalAppointmentDetail" component={HospitalAppointmentDetail} />
        <Stack.Screen name="HospitalMarkComplete" component={HospitalMarkComplete} />
      </Stack.Navigator>
      {/* Sits above every screen. Cannot be dismissed: the nurse must accept or decline. */}
      <EmergencyAlertModal />
    </HospitalProvider>
  );
}
