import React, { useEffect, useMemo, useState } from "react";
import { Alert, Text, View } from "react-native";
import { assignDoctorToSeat, createDoctor, getDoctorSeats, getEmergencyConditions, getSpecialties, updateDoctor } from "../../../api/hospital";
import { Button, Card, Chip, ErrorText, Field, Screen, SectionTitle } from "../../../components/ui";
import { normSeats } from "../../../utils/derive";
import { asList } from "../../../utils/format";
import { useHospitalStore } from "../../provider-state/store";

const SEXES = ["MALE", "FEMALE", "OTHER"];

export default function HospitalDoctorForm({ navigation, route }: any) {
  const { hospitalId } = useHospitalStore();
  const doctor = route?.params?.doctor;
  const editing = !!doctor?.id;

  const [name, setName] = useState(doctor?.name || "");
  const [age, setAge] = useState(doctor?.age != null ? String(doctor.age) : "");
  const [sex, setSex] = useState<string>(doctor?.sex || "");
  const [tnmc, setTnmc] = useState(doctor?.tnmcNumber || "");
  const [specialty, setSpecialty] = useState((doctor?.specialties || [])[0] || "");
  const [qualification, setQualification] = useState((doctor?.qualifications || []).join(", "));
  const [experience, setExperience] = useState(doctor?.yearsOfExperience != null ? String(doctor.yearsOfExperience) : "");
  const [fee, setFee] = useState(doctor?.consultationFee != null ? String(doctor.consultationFee) : "");
  const [timings, setTimings] = useState(doctor?.availability?.customTimings || "Mon-Fri 09:00-17:00");
  const [phone, setPhone] = useState(doctor?.contactDetails?.phone || "");
  const [email, setEmail] = useState(doctor?.contactDetails?.email || "");
  const [emergencyCodes, setEmergencyCodes] = useState<string[]>(doctor?.emergencyConditionsHandled || []);

  const [specialtyList, setSpecialtyList] = useState<string[]>([]);
  const [conditions, setConditions] = useState<{ code: string; name: string }[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    getSpecialties().then((d: any) => {
      const names = asList(d).flatMap((x: any) => (x.specialties ? x.specialties.map((s: any) => s.name ?? s) : [x.name ?? x])).filter(Boolean);
      setSpecialtyList(Array.from(new Set(names as string[])));
    }).catch(() => {});
    getEmergencyConditions().then((d: any) => {
      setConditions(asList(d).map((c: any) => ({ code: String(c.code ?? c.id), name: c.name ?? c.label ?? c.description ?? String(c.code ?? c.id) })));
    }).catch(() => {});
  }, []);

  const suggestions = useMemo(() => {
    const q = specialty.trim().toLowerCase();
    if (!q || specialtyList.some((s) => s.toLowerCase() === q)) return [];
    return specialtyList.filter((s) => s.toLowerCase().includes(q)).slice(0, 8);
  }, [specialty, specialtyList]);

  const toggleCode = (code: string) => setEmergencyCodes((c) => (c.includes(code) ? c.filter((x) => x !== code) : [...c, code]));

  const save = async () => {
    if (!name.trim() || !tnmc.trim() || !specialty.trim() || !age.trim() || !sex) {
      setError("Please fill name, age, sex, TNMC number and specialty.");
      return;
    }
    if (!hospitalId) { setError("Hospital profile is still loading. Try again in a moment."); return; }
    setSaving(true); setError("");
    const feeNum = Number(fee || 0);
    const otherAssoc = (doctor?.hospitalAssociations || []).filter((a: any) => String(a.hospitalId) !== hospitalId);
    const body = {
      name: name.trim(),
      age: Number(age),
      sex,
      tnmcNumber: tnmc.trim(),
      qualifications: qualification.split(",").map((x: string) => x.trim()).filter(Boolean),
      specialties: [specialty.trim()],
      emergencyConditionsHandled: emergencyCodes,
      yearsOfExperience: Number(experience || 0),
      consultationFee: feeNum,
      availability: { type: "CUSTOM_TIMINGS", customTimings: timings.trim() },
      engagementType: doctor?.engagementType || "REGULAR",
      doctorCategory: doctor?.doctorCategory || "PRIMARY",
      contactDetails: { phone: phone.trim(), email: email.trim() },
      hospitalAssociations: [
        ...otherAssoc,
        { hospitalId, department: specialty.trim(), consultationFee: feeNum, active: true },
      ],
    };
    try {
      if (editing) {
        await updateDoctor(doctor.id, body);
        Alert.alert("Saved", "Doctor details updated.");
      } else {
        const created = await createDoctor(body);
        // One doctor per seat: put the new doctor in a free seat straight away.
        let seated = false;
        try {
          const seats = normSeats(await getDoctorSeats());
          const free = seats.seats.find((s) => !s.doctorId);
          if (free && created?.id) { await assignDoctorToSeat(free.id, String(created.id)); seated = true; }
        } catch { /* handled below */ }
        Alert.alert(
          "Doctor added",
          seated ? "Doctor added and seated. Switch Available on to start taking bookings." : "Doctor added, but no free seat was available. Buy a seat so patients can book this doctor.",
        );
      }
      navigation.goBack();
    } catch (e: any) {
      setError(e?.message || "Unable to save doctor.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Screen
      title={editing ? "Edit Doctor" : "Add Doctor"} onBack={() => navigation.goBack()}
      footer={<Button title={editing ? "Save changes" : "Add doctor"} loading={saving} onPress={save} />}
    >
      <Card>
        <Field label="Full name" value={name} onChangeText={setName} placeholder="Dr. Anitha Raman" />
        <View style={{ flexDirection: "row", gap: 12 }}>
          <View style={{ flex: 1 }}><Field label="Age" value={age} onChangeText={setAge} keyboardType="number-pad" placeholder="41" /></View>
          <View style={{ flex: 1 }}><Field label="Experience (yrs)" value={experience} onChangeText={setExperience} keyboardType="number-pad" placeholder="15" /></View>
        </View>
        <Text style={{ color: "#66758B", fontWeight: "600", fontSize: 13, marginBottom: 8 }}>Sex</Text>
        <View style={{ flexDirection: "row", gap: 8, marginBottom: 12 }}>
          {SEXES.map((s) => <Chip key={s} label={s[0] + s.slice(1).toLowerCase()} active={sex === s} onPress={() => setSex(s)} />)}
        </View>
        <Field label="TNMC registration number" value={tnmc} onChangeText={setTnmc} autoCapitalize="characters" />
        <Field label="Specialty" value={specialty} onChangeText={setSpecialty} placeholder="e.g. Cardiology" />
        {suggestions.length > 0 ? (
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: -4, marginBottom: 12 }}>
            {suggestions.map((s) => <Chip key={s} label={s} onPress={() => setSpecialty(s)} />)}
          </View>
        ) : null}
        <Field label="Qualifications (comma separated)" value={qualification} onChangeText={setQualification} placeholder="MBBS, MD" />
        <Field label="Consultation fee (₹)" value={fee} onChangeText={setFee} keyboardType="number-pad" />
        <Field label="Timings" value={timings} onChangeText={setTimings} placeholder="Mon-Fri 10am-1pm" />
      </Card>

      <Card>
        <Field label="Phone" value={phone} onChangeText={setPhone} keyboardType="phone-pad" />
        <Field label="Email" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" />
      </Card>

      {conditions.length > 0 ? (
        <>
          <SectionTitle title="Emergencies this doctor handles" />
          <Card>
            <Text style={{ color: "#66758B", fontSize: 12.5, marginBottom: 10, lineHeight: 17 }}>
              Patients are only routed to you for emergencies a doctor on duty can handle.
            </Text>
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
              {conditions.map((c) => <Chip key={c.code} label={c.name} active={emergencyCodes.includes(c.code)} onPress={() => toggleCode(c.code)} />)}
            </View>
          </Card>
        </>
      ) : null}
      <ErrorText text={error} />
    </Screen>
  );
}
