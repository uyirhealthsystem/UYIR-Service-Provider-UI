import { useAuth } from "../auth/store";
import AuthRoutes from "./AuthRoutes";
import ProviderRoutes from "./ProviderRoutes";

export default function Routes() {
  const { user } = useAuth();

  return user ? <ProviderRoutes /> : <AuthRoutes />;
}
