// Common authentication layout
