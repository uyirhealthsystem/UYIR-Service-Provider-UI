// Provider routing shell
