// Authentication types
