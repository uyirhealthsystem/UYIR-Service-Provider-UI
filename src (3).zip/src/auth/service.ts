// Authentication business logic
