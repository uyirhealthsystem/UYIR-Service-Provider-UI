import { setProUserId } from "../providers/pro/api/client";
import { createContext, useContext, useState, type ReactNode } from "react";
import { clearAuthSession, setAuthSession } from "./session";

type AuthUser = {
  id: string;
  sub: string;
  providerType: string;
  role: string;
  accessToken: string;
  refreshToken?: string;
};

type AuthContextValue = {
  user: AuthUser | null;
  setUser: (user: AuthUser | null) => void;
  logout: () => void;
};

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUserState] = useState<AuthUser | null>(null);

  const setUser = (nextUser: AuthUser | null) => {
    if (!nextUser) {
      clearAuthSession();
      setProUserId(null);
      setUserState(null);
      return;
    }

    setAuthSession({
      accessToken: nextUser.accessToken,
      refreshToken: nextUser.refreshToken,
      userId: nextUser.sub || nextUser.id,
      role: nextUser.providerType || nextUser.role,
    });

    setUserState(nextUser);
  };

  const logout = () => {
    clearAuthSession();
    setProUserId(null);
    setUserState(null);
  };

  return (
    <AuthContext.Provider value={{ user, setUser, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);

  if (!context) {
    throw new Error("useAuth must be used inside AuthProvider");
  }

  return context;
}
