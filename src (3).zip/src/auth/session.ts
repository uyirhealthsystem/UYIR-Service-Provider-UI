let accessToken = "";
let refreshToken = "";
let userId = "";
let role = "";

export function setAuthSession(data: {
  accessToken?: string;
  refreshToken?: string;
  userId?: string;
  role?: string;
}) {
  accessToken = data.accessToken || "";
  refreshToken = data.refreshToken || "";
  userId = data.userId || "";
  role = data.role || "";
}

export function clearAuthSession() {
  accessToken = "";
  refreshToken = "";
  userId = "";
  role = "";
}

export function getAccessToken() {
  return accessToken;
}

export function getRefreshToken() {
  return refreshToken;
}

export function getAuthUserId() {
  return userId;
}

export function getAuthRole() {
  return role;
}
