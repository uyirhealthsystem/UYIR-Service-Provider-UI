import { GoogleSignin } from "@react-native-google-signin/google-signin";
import { useState } from "react";
import { Pressable, Text, TextInput, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { useLanguage } from "../../language";
import LanguageSelector from "../../language/components/LanguageSelector";
import { AUTH_BASE_URL } from "../../config/env";

GoogleSignin.configure({
  webClientId:
    "407194530114-h4esr7s9me5ottchk29eks8gf7sdo4sb.apps.googleusercontent.com",
});

export default function Login({ navigation }: any) {
  const { t } = useLanguage();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleLogin = async () => {
    if (!email.trim() || !password) {
      setError("Please enter email and password");
      return;
    }

    try {
      setLoading(true);
      setError("");

      const response = await fetch(`${AUTH_BASE_URL}/auth/email/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: email.trim(),
          password,
          clientId: "service-provider-app",
        }),
      });

      const data = await response.json();


      if (!response.ok) {
        setError(
          data?.error?.message || data?.message || "Invalid email or password.",
        );
        return;
      }

      // Login successful
      console.log("Login successful");
      console.log("Role:", data.role);

      // Move to next page ONLY after successful login
      navigation.navigate("OTP", {
        mode: "login",
        role: data.role,
        accessToken: data.accessToken,
        refreshToken: data.refreshToken,
      });
    } catch (error) {
      console.log("Login error:", error);
      setError("Unable to connect to server");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    try {
      await GoogleSignin.hasPlayServices();

      const result = await GoogleSignin.signIn();

      if (result.type !== "success") {
        console.log("Google Sign-In cancelled");
        return;
      }

      const idToken = result.data.idToken;

      if (!idToken) {
        console.log("Google ID token not received");
        return;
      }

      const response = await fetch(`${AUTH_BASE_URL}/auth/google/native`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          idToken,
          clientId: "service-provider-app",
          role: "HOSPITAL",
        }),
      });

      const data = await response.json();

      console.log("Google backend response:", data);

      if (!response.ok) {
        console.log("Google login failed:", data);
        return;
      }

      console.log("Google login successful");
      console.log("Role:", data.role);

      // Google navigation can be handled later
    } catch (error) {
      console.log("Google Login Error:", error);
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#fff" }}>
      <View style={{ padding: 20 }}>
        <LanguageSelector />
      </View>

      <View
        style={{
          flex: 1,
          justifyContent: "center",
          padding: 24,
        }}
      >
        {/* Logo */}
        <View
          style={{
            alignItems: "center",
            marginBottom: 45,
          }}
        >
          <Text
            style={{
              fontSize: 34,
              fontWeight: "800",
              color: "#173FD1",
            }}
          >
            Uyir
          </Text>

          <Text
            style={{
              marginTop: 3,
              color: "#555",
            }}
          >
            Health Provider
          </Text>
        </View>

        {/* Title */}
        <Text
          style={{
            fontSize: 28,
            fontWeight: "700",
            color: "#111827",
          }}
        >
          {t("auth.login.title")}
        </Text>

        <Text
          style={{
            marginTop: 8,
            color: "#6B7280",
          }}
        >
          {t("auth.login.subtitle")}
        </Text>

        {/* Email */}
        <TextInput
          placeholder={t("auth.login.email")}
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          autoCapitalize="none"
          autoCorrect={false}
          editable={!loading}
          placeholderTextColor="#9CA3AF"
          autoCapitalize="none"
          autoCorrect={false}
          selectionColor="#2563EB"
          style={{
            marginTop: 28,
            height: 60,
            borderWidth: 1,
            borderColor: "#E1E5EC",
            borderRadius: 12,
            paddingHorizontal: 18,
            backgroundColor: "#FFFFFF",
            color: "#111827",
            fontSize: 16,
          }}
        />

        {/* Password */}
        <TextInput
          placeholder={t("auth.login.password")}
          value={password}
          onChangeText={setPassword}
          secureTextEntry
          editable={!loading}
          placeholderTextColor="#9CA3AF"
          autoCapitalize="none"
          autoCorrect={false}
          selectionColor="#2563EB"
          style={{
            marginTop: 12,
            height: 60,
            borderWidth: 1,
            borderColor: "#E1E5EC",
            borderRadius: 12,
            paddingHorizontal: 18,
            backgroundColor: "#FFFFFF",
            color: "#111827",
            fontSize: 16,
          }}
        />

        {/* Error */}
        {error ? (
          <Text
            style={{
              marginTop: 10,
              color: "#DC2626",
            }}
          >
            {error}
          </Text>
        ) : null}

        {/* Forgot Password */}
        <Pressable
          onPress={() => navigation.navigate("ForgotPassword")}
          disabled={loading}
          style={{
            alignSelf: "flex-end",
            marginTop: 10,
          }}
        >
          <Text
            style={{
              color: "#173FD1",
              fontWeight: "600",
            }}
          >
            {t("auth.login.forgotPassword")}
          </Text>
        </Pressable>

        {/* Login */}
        <Pressable
          onPress={handleLogin}
          disabled={loading}
          style={{
            marginTop: 20,
            backgroundColor: "#173FD1",
            padding: 16,
            borderRadius: 12,
            alignItems: "center",
            opacity: loading ? 0.6 : 1,
          }}
        >
          <Text
            style={{
              color: "#fff",
              fontSize: 16,
              fontWeight: "700",
            }}
          >
            {loading ? "Logging in..." : t("auth.login.login")}
          </Text>
        </Pressable>

        {/* Divider */}
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            marginVertical: 20,
          }}
        >
          <View
            style={{
              flex: 1,
              height: 1,
              backgroundColor: "#E5E7EB",
            }}
          />

          <Text
            style={{
              marginHorizontal: 12,
              color: "#777",
            }}
          >
            {t("auth.login.or")}
          </Text>

          <View
            style={{
              flex: 1,
              height: 1,
              backgroundColor: "#E5E7EB",
            }}
          />
        </View>

        {/* Google Login */}
        <Pressable
          onPress={handleGoogleLogin}
          disabled={loading}
          style={{
            borderWidth: 1,
            borderColor: "#E1E5EC",
            padding: 15,
            borderRadius: 12,
            alignItems: "center",
            opacity: loading ? 0.6 : 1,
          }}
        >
          <Text
            style={{
              fontWeight: "600",
            }}
          >
            {t("auth.login.google")}
          </Text>
        </Pressable>

        {/* Register */}
        <Pressable
          onPress={() => navigation.navigate("Register")}
          disabled={loading}
          style={{
            alignItems: "center",
            marginTop: 24,
          }}
        >
          <Text
            style={{
              color: "#6B7280",
            }}
          >
            {t("auth.login.noAccount")}{" "}
            <Text
              style={{
                color: "#173FD1",
                fontWeight: "700",
              }}
            >
              {t("auth.login.register")}
            </Text>
          </Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}
