import { useState } from "react";
import { Pressable, Text, TextInput, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { getProviderMe } from "../../providers/ecg-on-wheels/api/getProviderMe";
import { getMyProfile as getAmbulanceProfile } from "../../providers/ambulance/api/profile";
import { getProfile } from "../../providers/health-partner/api/profile";
import { setLaboratoryAccessToken } from "../../providers/laboratory/api/client";
import { getProviderRegistrationStatus } from "../../providers/laboratory/api/laboratory";
import { setProUserId } from "../../providers/pro/api/client";
import { getMyProfile } from "../../providers/pro/api/profile";
import { getNurseProfile, getCaretakerProfile, getPhysiotherapistProfile } from "../../providers/home-based-care/api/profile";
import { setHbcUserId } from "../../providers/home-based-care/api/client";
import { setAuthSession } from "../session";
import { useAuth } from "../store";
import { getUserIdFromAccessToken } from "../token";


function isHealthPartnerProfileMissing(data: any): boolean {
  if (data == null) return true;

  if (typeof data?.registered === "boolean") return !data.registered;
  if (typeof data?.isRegistered === "boolean") return !data.isRegistered;
  if (typeof data?.data?.registered === "boolean") return !data.data.registered;
  if (typeof data?.data?.isRegistered === "boolean") return !data.data.isRegistered;

  const message = String(
    data?.message || data?.error?.message || data?.data?.message || "",
  ).toLowerCase();
  if (/(not found|not registered|no profile|profile does not exist|user does not exist)/.test(message)) {
    return true;
  }

  const profile = data?.data?.profile ?? data?.profile ?? data?.data ?? data;
  if (!profile || typeof profile !== "object") return true;
  if (Object.keys(profile).length === 0) return true;

  // The HP collection's GET /api/v1/profile response includes fullName and districtName.
  return !(
    profile.fullName ||
    profile.name ||
    profile.healthPartnerId ||
    profile.id ||
    profile.userId ||
    profile.districtId ||
    profile.districtName
  );
}

function isRegisteredResponse(data: any) {
  if (typeof data === "boolean") {
    return data;
  }

  if (typeof data?.registered === "boolean") {
    return data.registered;
  }

  if (typeof data?.isRegistered === "boolean") {
    return data.isRegistered;
  }

  if (typeof data?.data?.registered === "boolean") {
    return data.data.registered;
  }

  if (typeof data?.data?.isRegistered === "boolean") {
    return data.data.isRegistered;
  }

  return true;
}

export default function OTP({ route, navigation }: any) {
  const { setUser } = useAuth();

  const mode = route.params?.mode;
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const verify = async () => {
    if (mode === "register") {
      navigation.replace("ProviderType");
      return;
    }

    const normalizedRole = String(route.params?.role || "")
      .trim()
      .toUpperCase()
      .replace(/[\s-]+/g, "_");
    // The Health Partner service contract uses the short role code HP.
    const role = ["HP", "HEALTH_PARTNER", "HEALTHPARTNER"].includes(normalizedRole)
      ? "HP"
      : normalizedRole;
    const isHealthPartnerRole = role === "HP";
    const accessToken = route.params?.accessToken;
    const refreshToken = route.params?.refreshToken;

    if (!accessToken) {
      setError("Access token not received");
      return;
    }

    const userId = getUserIdFromAccessToken(accessToken);

    if (!userId) {
      setError("User ID (sub) not found in access token");
      return;
    }

    try {
      setLoading(true);
      setError("");

      console.log("OTP verified");
      console.log("Provider role:", role);
      console.log("User ID from access token sub:", userId);

      if (role === "LS") {
        setLaboratoryAccessToken(accessToken, userId);

        setAuthSession({
          accessToken,
          refreshToken,
          userId,
          role,
        });

        try {
          const registration = await getProviderRegistrationStatus();

          console.log("LS registration check:", registration.registered);

          if (!registration.registered) {
            navigation.replace("LaboratoryRegistration", {
              sub: userId,
              role,
              accessToken,
              refreshToken,
            });
            return;
          }
        } catch (checkError: any) {
          console.log("LS registration check error:", checkError);
          throw checkError;
        }
      }

      if (isHealthPartnerRole) {
        // Put the authenticated token in the API session so the HP service
        // can check whether this Auth user already has an HP profile.
        setAuthSession({
          accessToken,
          refreshToken,
          userId,
          role,
        });

        try {
          const profileResponse = await getProfile();
          const profileMissing = isHealthPartnerProfileMissing(profileResponse);

          console.log("HP registration profile response:", profileResponse);
          console.log("HP registration check - profile missing:", profileMissing);

          if (profileMissing) {
            navigation.replace("HealthPartnerRegistration", {
              sub: userId,
              role,
              accessToken,
              refreshToken,
            });
            return;
          }
        } catch (checkError: any) {
          console.log("HP registration check error:", checkError);

          if (checkError?.status === 404) {
            navigation.replace("HealthPartnerRegistration", {
              sub: userId,
              role,
              accessToken,
              refreshToken,
            });
            return;
          }

          throw checkError;
        }
      }

      if (
        role === "ECG" ||
        role === "ECG_ON_WHEELS" ||
        role === "ECG_ON_WHEEL"
      ) {
        setAuthSession({
          accessToken,
          refreshToken,
          userId,
          role,
        });

        try {
          const providerResponse = await getProviderMe();
          const provider =
            providerResponse?.data ??
            providerResponse?.provider ??
            providerResponse;
          console.log(
            "ECG registration check:",
            Boolean(provider?.id || provider?.providerId),
          );

          if (!provider?.id && !provider?.providerId) {
            navigation.replace("ECGRegistration", {
              sub: userId,
              role,
              accessToken,
              refreshToken,
            });
            return;
          }
        } catch (checkError: any) {
          console.log("ECG registration check error:", checkError);
          if (checkError?.status === 404) {
            navigation.replace("ECGRegistration", {
              sub: userId,
              role,
              accessToken,
              refreshToken,
            });
            return;
          }
          throw checkError;
        }
      }

      if (role === "HBC") {
        setAuthSession({
          accessToken,
          refreshToken,
          userId,
          role,
        });
        setHbcUserId(userId);

        // Check the HBC provider profile, the same way PRO and Laboratory
        // check their own provider service. Do not use the Auth /api/users URL.
        const profileChecks = [
          { type: "NURSE", load: getNurseProfile },
          { type: "CARETAKER", load: getCaretakerProfile },
          { type: "PHYSIOTHERAPIST", load: getPhysiotherapistProfile },
        ];

        let matchedProfile = false;

        for (const check of profileChecks) {
          try {
            const profileResponse = await check.load();
            const profile =
              profileResponse?.data?.profile ??
              profileResponse?.profile ??
              profileResponse?.data ??
              profileResponse;

            console.log(`HBC ${check.type} profile response:`, profileResponse);

            if (profile && typeof profile === "object" && Object.keys(profile).length > 0) {
              console.log(`HBC registered provider type: ${check.type}`);
              console.log("HBC profile ID:", profile.id || profile.providerId || profile.nurseId || profile.caretakerId || profile.physiotherapistId || "ID not present in response");
              matchedProfile = true;
              break;
            }
          } catch (profileError: any) {
            console.log(`HBC ${check.type} profile check:`, {
              status: profileError?.status,
              message: profileError?.message,
              data: profileError?.data,
            });

            // The profile endpoint for another HBC subtype may return 404.
            if (profileError?.status === 404 || profileError?.status === 400) {
              continue;
            }

            throw profileError;
          }
        }

        console.log("HBC registration/profile found:", matchedProfile);

        if (!matchedProfile) {
          navigation.replace("HBCRegistrationType", {
            sub: userId, role, accessToken, refreshToken,
          });
          return;
        }
      }

      if (role === "AMBULANCE_DRIVER" || role === "AMBULANCE") {
        setAuthSession({ accessToken, refreshToken, userId, role });
        try {
          await getAmbulanceProfile();
        } catch (profileError: any) {
          if (profileError?.status === 404) {
            navigation.replace("AmbulanceRegistration", {
              sub: userId, role, accessToken, refreshToken,
            });
            return;
          }
          throw profileError;
        }
      }

      if (role === "HOSPITAL") {
        setAuthSession({ accessToken, refreshToken, userId, role });
      }

      if (role === "DOCTOR") {
        // The supplied Hospital collection has no doctor "me/profile" endpoint.
        // Keep the individual DoctorRegistration screen available via ProviderType;
        // do not guess a user-specific status endpoint here.
      }

      if (role === "LSC") {
        // The supplied Lab & Scan collection defines POST /collector but no
        // collector self-profile endpoint to reliably detect prior registration.
      }

      if (role === "PRO") {
        setProUserId(userId);

        try {
          const profileResponse = await getMyProfile(userId);
          const registered = isRegisteredResponse(profileResponse);

          console.log("PRO registration check:", registered);

          if (!registered) {
            navigation.replace("ProRegistration", {
              sub: userId,
              role,
              accessToken,
              refreshToken,
            });
            return;
          }
        } catch (checkError: any) {
          console.log("PRO registration check error:", checkError);

          if (checkError?.status === 404) {
            navigation.replace("ProRegistration", {
              sub: userId,
              role,
              accessToken,
              refreshToken,
            });
            return;
          }

          throw checkError;
        }
      }

      setUser({
        id: userId,
        sub: userId,
        providerType: role,
        role,
        accessToken,
        refreshToken,
      });
    } catch (verifyError: any) {
      console.log("OTP verification error:", verifyError);
      setError(verifyError?.message || "Unable to verify account");
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#fff" }}>
      <View style={{ flex: 1, justifyContent: "center", padding: 24 }}>
        <Pressable onPress={() => navigation.goBack()}>
          <Text style={{ fontSize: 28 }}>‹</Text>
        </Pressable>

        <Text style={{ marginTop: 24, fontSize: 28, fontWeight: "700" }}>
          Verify your account
        </Text>

        <Text style={{ marginTop: 8, color: "#6B7280", lineHeight: 21 }}>
          Enter the verification code sent to your email.
        </Text>

        <TextInput
          placeholder="Enter OTP"
          keyboardType="number-pad"
          maxLength={6}
          style={{
            marginTop: 28,
            borderWidth: 1,
            borderColor: "#E1E5EC",
            borderRadius: 12,
            padding: 16,
            fontSize: 18,
            letterSpacing: 5,
          }}
        />

        {error ? (
          <Text style={{ marginTop: 12, color: "#DC2626" }}>{error}</Text>
        ) : null}

        <Pressable
          onPress={verify}
          disabled={loading}
          style={{
            marginTop: 20,
            backgroundColor: "#173FD1",
            padding: 16,
            borderRadius: 12,
            alignItems: "center",
            opacity: loading ? 0.6 : 1,
          }}
        >
          <Text style={{ color: "#fff", fontSize: 16, fontWeight: "700" }}>
            {loading ? "Checking..." : "Verify"}
          </Text>
        </Pressable>

        <Pressable style={{ alignItems: "center", marginTop: 20 }}>
          <Text style={{ color: "#173FD1", fontWeight: "600" }}>
            Resend code
          </Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}
