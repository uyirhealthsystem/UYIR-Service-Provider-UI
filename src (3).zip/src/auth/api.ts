// Authentication API
